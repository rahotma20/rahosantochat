export type MediaType = 'image' | 'video' | 'audio' | 'document';

export interface MediaAttachment {
  id: string;
  type: MediaType;
  url: string;
  name: string;
  size: number; // in bytes
  mimeType?: string;
  duration?: number; // for audio/video in seconds
  thumbnailUrl?: string;
  dimensions?: { width: number; height: number };
}

export interface EncryptedPayload {
  ciphertext: string;
  iv: string;
  tag?: string;
  algorithm: string;
  fingerprint: string;
  encryptedAt: number;
}

export interface MessageReaction {
  emoji: string;
  users: string[]; // 'me' or contactId
}

export interface MessageReplyInfo {
  id: string;
  senderName: string;
  text: string;
  mediaType?: MediaType;
}

export interface Message {
  id: string;
  senderId: string; // 'me' or contactId
  recipientId: string;
  text: string;
  timestamp: number;
  status: 'sending' | 'sent' | 'delivered' | 'read';
  media?: MediaAttachment[];
  encryptedPayload: EncryptedPayload;
  replyTo?: MessageReplyInfo;
  reactions?: { [emoji: string]: string[] }; // emoji -> array of senderIds
  isStarred?: boolean;
  isDeleted?: boolean;
  disappearingInSeconds?: number;
}

export interface Contact {
  id: string;
  name: string;
  handle: string;
  phone: string;
  email: string;
  role: string;
  avatar: string;
  avatarColor: string;
  status: 'online' | 'offline' | 'typing' | 'away';
  lastSeen?: string;
  safetyNumber: string;
  isVerified: boolean;
  isPinned?: boolean;
  isMuted?: boolean;
  isBlocked?: boolean;
  disappearingTimer: number; // 0 = off, 86400 = 24h, 604800 = 7d
  customPublicKeyFingerprint: string;
}

export interface CallSession {
  isActive: boolean;
  contact: Contact;
  type: 'audio' | 'video';
  status: 'calling' | 'ringing' | 'connected' | 'ended';
  startedAt?: number;
  durationSeconds: number;
  isMuted: boolean;
  isVideoEnabled: boolean;
}

export interface StatusStory {
  id: string;
  contactId: string;
  contactName: string;
  contactAvatar: string;
  timestamp: number;
  text?: string;
  mediaUrl?: string;
  backgroundColor?: string;
  textColor?: string;
  isViewed?: boolean;
}
