import { Contact, Message } from '../types/chat';

export const INITIAL_CONTACTS: Contact[] = [
  {
    id: 'santo-rahman',
    name: 'Santo Rahman',
    handle: '@santorahman',
    phone: '+62 812-4455-8890',
    email: 'santo.rahman@rahosanto.net',
    role: 'Lead Systems Architect & Co-Founder',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    avatarColor: 'from-emerald-500 to-teal-700',
    status: 'online',
    lastSeen: 'Active now',
    safetyNumber: '48920 18274 91823 09182 48192 38471 92837 46192 84729 18472 94827 19284',
    isVerified: true,
    isPinned: true,
    isMuted: false,
    isBlocked: false,
    disappearingTimer: 0,
    customPublicKeyFingerprint: 'SHA256:7B:4E:99:A1:0F:32:8D:6C:55:20:AA:FE:19:62:3B:48'
  },
  {
    id: 'aura-lestari',
    name: 'Aura Lestari',
    handle: '@auralestari',
    phone: '+62 813-8821-3944',
    email: 'aura.lestari@designlab.io',
    role: 'Senior Product & Motion Designer',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
    avatarColor: 'from-purple-500 to-indigo-700',
    status: 'online',
    lastSeen: 'Active now',
    safetyNumber: '19482 92834 81920 38472 81920 38472 84920 18472 93847 19284 83920 48192',
    isVerified: true,
    isPinned: true,
    isMuted: false,
    isBlocked: false,
    disappearingTimer: 86400, // 24 hours
    customPublicKeyFingerprint: 'SHA256:3C:99:21:FD:A4:77:01:8C:99:E1:54:BA:88:41:2C:90'
  },
  {
    id: 'dewi-anggraeni',
    name: 'Dewi Anggraeni',
    handle: '@dewi_sec',
    phone: '+62 815-9922-1133',
    email: 'dewi@cyberguard.id',
    role: 'Cryptographic Security Officer',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    avatarColor: 'from-cyan-500 to-blue-700',
    status: 'offline',
    lastSeen: 'Yesterday at 8:45 PM',
    safetyNumber: '92837 46192 84729 18472 94827 19284 48920 18274 91823 09182 48192 38471',
    isVerified: true,
    isPinned: false,
    isMuted: false,
    isBlocked: false,
    disappearingTimer: 0,
    customPublicKeyFingerprint: 'SHA256:AA:22:90:38:CE:59:71:0F:B2:67:88:1C:33:DE:74:91'
  },
  {
    id: 'budi-pratama',
    name: 'Budi Pratama',
    handle: '@budi_infra',
    phone: '+62 811-3344-9988',
    email: 'budi.p@cloudops.net',
    role: 'Cloud Infrastructure & Media Streaming',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    avatarColor: 'from-amber-500 to-orange-700',
    status: 'away',
    lastSeen: '15 mins ago',
    safetyNumber: '83920 48192 19482 92834 81920 38472 81920 38472 84920 18472 93847 19284',
    isVerified: false,
    isPinned: false,
    isMuted: true,
    isBlocked: false,
    disappearingTimer: 0,
    customPublicKeyFingerprint: 'SHA256:11:44:99:CB:02:88:6A:E7:33:51:79:08:FA:49:EE:12'
  }
];

export const INITIAL_MESSAGES: Record<string, Message[]> = {
  'santo-rahman': [
    {
      id: 'msg-s1',
      senderId: 'santo-rahman',
      recipientId: 'me',
      text: 'Hi Rahotma! Welcome to Rahosantochat. I tested the mutual cryptographic handshakes between our devices, and everything is completely locked down with AES-256-GCM.',
      timestamp: Date.now() - 1000 * 60 * 60 * 2, // 2 hours ago
      status: 'read',
      encryptedPayload: {
        ciphertext: 'T1v8K3nQ2L9pW4vY==M2Q0NzM1N2E5ODc=',
        iv: '4f29a0c8b3e15729d4e218c6',
        tag: '4f29a0c8',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:7B:4E:99:A1:0F:32:8D:6C',
        encryptedAt: Date.now() - 1000 * 60 * 60 * 2
      },
      reactions: { '🔒': ['me'], '👍': ['me', 'santo-rahman'] }
    },
    {
      id: 'msg-s2',
      senderId: 'me',
      recipientId: 'santo-rahman',
      text: 'Awesome Santo! Did you prepare the latest architectural blueprint and server topology files we discussed yesterday?',
      timestamp: Date.now() - 1000 * 60 * 55,
      status: 'read',
      encryptedPayload: {
        ciphertext: 'QXZtOTkxMzA5OGFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3',
        iv: '18a4c9e7b23019f5aa38cd10',
        tag: '18a4c9e7',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:12:34:56:78:90:AB:CD:EF',
        encryptedAt: Date.now() - 1000 * 60 * 55
      }
    },
    {
      id: 'msg-s3',
      senderId: 'santo-rahman',
      recipientId: 'me',
      text: 'Yes! Here is the encrypted high-resolution site blueprint and the project specification document. You can download or preview them directly.',
      timestamp: Date.now() - 1000 * 60 * 45,
      status: 'read',
      encryptedPayload: {
        ciphertext: 'WmV4YW1wbGVDaXBoZXJUZXh0U2FudG9SYWhtYW5NZWRpYQ==',
        iv: 'c819fa20b417e3589a10294c',
        tag: 'c819fa20',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:7B:4E:99:A1:0F:32:8D:6C',
        encryptedAt: Date.now() - 1000 * 60 * 45
      },
      media: [
        {
          id: 'med-s1',
          type: 'image',
          url: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1200&q=80',
          name: 'Rahosanto_HQ_Blueprint_Render.jpg',
          size: 2457600, // 2.4 MB
          mimeType: 'image/jpeg',
          dimensions: { width: 1200, height: 800 }
        },
        {
          id: 'med-s2',
          type: 'document',
          url: '#',
          name: 'Rahosanto_Encrypted_Specs_v2.4.pdf',
          size: 3840000, // 3.8 MB
          mimeType: 'application/pdf'
        }
      ],
      reactions: { '❤️': ['me'], '🔥': ['me'] }
    },
    {
      id: 'msg-s4',
      senderId: 'santo-rahman',
      recipientId: 'me',
      text: 'Listen to this quick audio briefing regarding the deployment timeline.',
      timestamp: Date.now() - 1000 * 60 * 30,
      status: 'read',
      encryptedPayload: {
        ciphertext: 'QXVkaW9Ob3RlVm9pY2VCcmllZmluZ0NpcGhlclRleHQ=',
        iv: 'e391ba05c8721498fa011923',
        tag: 'e391ba05',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:7B:4E:99:A1:0F:32:8D:6C',
        encryptedAt: Date.now() - 1000 * 60 * 30
      },
      media: [
        {
          id: 'med-s3',
          type: 'audio',
          url: 'https://assets.mixkit.co/active_storage/sfx/2874/2874-preview.mp3',
          name: 'VoiceNote_Timeline_Update.mp3',
          size: 614400, // 600 KB
          duration: 38, // 38 seconds
          mimeType: 'audio/mpeg'
        }
      ],
      isStarred: true
    },
    {
      id: 'msg-s5',
      senderId: 'me',
      recipientId: 'santo-rahman',
      text: 'Reviewing the blueprint right now. The security perimeter architecture looks flawless. Let me send over our UI mockups as well!',
      timestamp: Date.now() - 1000 * 60 * 10,
      status: 'delivered',
      replyTo: {
        id: 'msg-s3',
        senderName: 'Santo Rahman',
        text: 'Yes! Here is the encrypted high-resolution site blueprint...',
        mediaType: 'image'
      },
      encryptedPayload: {
        ciphertext: 'UmVwbHlNZXNzYWdlVG9TYW50b1JhaG1hbkNpcGhlclRleHQ=',
        iv: '7721ba99d2105436aa194e82',
        tag: '7721ba99',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:12:34:56:78:90:AB:CD:EF',
        encryptedAt: Date.now() - 1000 * 60 * 10
      }
    }
  ],
  'aura-lestari': [
    {
      id: 'msg-a1',
      senderId: 'aura-lestari',
      recipientId: 'me',
      text: 'Hey Rahotma! Here are the updated Dark & Emerald theme color palettes for Rahosantochat.',
      timestamp: Date.now() - 1000 * 60 * 120,
      status: 'read',
      encryptedPayload: {
        ciphertext: 'QXVyYURlc2lnblVwZGF0ZUNpcGhlcg==',
        iv: '9921bc4488331122aaff0012',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:3C:99:21:FD:A4:77',
        encryptedAt: Date.now() - 1000 * 60 * 120
      },
      media: [
        {
          id: 'med-a1',
          type: 'image',
          url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
          name: 'Rahosantochat_Palette_Concept.png',
          size: 1850000,
          mimeType: 'image/png'
        }
      ]
    },
    {
      id: 'msg-a2',
      senderId: 'me',
      recipientId: 'aura-lestari',
      text: 'The emerald accents against deep slate look super clean and trust-inspiring! Let us lock this in.',
      timestamp: Date.now() - 1000 * 60 * 90,
      status: 'read',
      encryptedPayload: {
        ciphertext: 'QXBwcm92YWxNZXNzYWdlQXVyYQ==',
        iv: '1234567890abcdef12345678',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:12:34:56:78:90:AB',
        encryptedAt: Date.now() - 1000 * 60 * 90
      },
      reactions: { '🙌': ['aura-lestari'] }
    }
  ],
  'dewi-anggraeni': [
    {
      id: 'msg-d1',
      senderId: 'dewi-anggraeni',
      recipientId: 'me',
      text: 'Greetings Rahotma. I completed the penetration test on our zero-knowledge end-to-end encryption pipeline. All key exchanges verify perfectly against our public fingerprints.',
      timestamp: Date.now() - 1000 * 60 * 60 * 24, // Yesterday
      status: 'read',
      encryptedPayload: {
        ciphertext: 'Q3J5cHRvQXVkaXRDb21wbGV0ZWRDb25maXJtYXRpb24=',
        iv: 'abcdef0123456789abcdef01',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:AA:22:90:38:CE:59',
        encryptedAt: Date.now() - 1000 * 60 * 60 * 24
      },
      media: [
        {
          id: 'med-d1',
          type: 'document',
          url: '#',
          name: 'Audit_Report_ZeroKnowledge_2026.pdf',
          size: 5120000,
          mimeType: 'application/pdf'
        }
      ]
    }
  ],
  'budi-pratama': [
    {
      id: 'msg-b1',
      senderId: 'budi-pratama',
      recipientId: 'me',
      text: 'Hi Rahotma, CDN media edge streaming is active in Singapore and Jakarta. File uploads are blazing fast now!',
      timestamp: Date.now() - 1000 * 60 * 300,
      status: 'delivered',
      encryptedPayload: {
        ciphertext: 'QnVkaUNETlN0YXR1c1VwZGF0ZQ==',
        iv: 'fedcba9876543210fedcba98',
        algorithm: 'AES-256-GCM',
        fingerprint: 'SHA256:11:44:99:CB:02:88',
        encryptedAt: Date.now() - 1000 * 60 * 300
      }
    }
  ]
};

export const INITIAL_STORIES = [
  {
    id: 'story-santo-1',
    contactId: 'santo-rahman',
    contactName: 'Santo Rahman',
    contactAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    timestamp: Date.now() - 1000 * 60 * 45, // 45m ago
    text: '🚀 High-throughput WebCrypto AES-256-GCM benchmarks looking stellar! Latency under 2ms.',
    mediaUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
    backgroundColor: '#0a332c',
    textColor: '#e9edef',
    isViewed: false
  },
  {
    id: 'story-aura-1',
    contactId: 'aura-lestari',
    contactName: 'Aura Lestari',
    contactAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
    timestamp: Date.now() - 1000 * 60 * 120, // 2h ago
    text: '✨ Crafted the new dark emerald aesthetic for our WhatsApp UI! Smooth transitions & crisp icons.',
    mediaUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80',
    backgroundColor: '#1b2c34',
    textColor: '#e9edef',
    isViewed: false
  },
  {
    id: 'story-dewi-1',
    contactId: 'dewi-anggraeni',
    contactName: 'Dewi Anggraeni',
    contactAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    timestamp: Date.now() - 1000 * 60 * 360, // 6h ago
    text: '🔒 Zero vulnerabilities detected in our cryptographic protocol audit today. Completely safe!',
    backgroundColor: '#0b4f40',
    textColor: '#e9edef',
    isViewed: true
  }
];
