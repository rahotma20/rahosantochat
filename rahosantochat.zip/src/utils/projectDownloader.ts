import JSZip from 'jszip';

// Code contents for creating the offline downloadable package
export async function downloadProjectZip(): Promise<void> {
  const zip = new JSZip();

  // Root files
  zip.file(
    'package.json',
    JSON.stringify(
      {
        name: 'rahosantochat',
        private: true,
        version: '1.0.0',
        type: 'module',
        scripts: {
          dev: 'vite --port=3000 --host=0.0.0.0',
          build: 'vite build',
          preview: 'vite preview',
          lint: 'tsc --noEmit'
        },
        dependencies: {
          '@google/genai': '^2.4.0',
          '@tailwindcss/vite': '^4.3.3',
          '@vitejs/plugin-react': '^6.1.1',
          dotenv: '^17.2.3',
          express: '^4.21.2',
          jszip: '^3.10.1',
          'lucide-react': '^0.546.0',
          motion: '^12.23.24',
          react: '^19.0.1',
          'react-dom': '^19.0.1',
          vite: '^8.3.0'
        },
        devDependencies: {
          '@types/express': '^4.17.21',
          '@types/node': '^22.14.0',
          '@types/react': '^19.3.0',
          '@types/react-dom': '^19.3.0',
          autoprefixer: '^10.4.21',
          esbuild: '^0.25.0',
          tailwindcss: '^4.3.3',
          tsx: '^4.21.0',
          typescript: '^7.0.2'
        }
      },
      null,
      2
    )
  );

  zip.file(
    'vite.config.ts',
    `import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
  server: {
    port: 3000,
    host: '0.0.0.0',
  },
});
`
  );

  zip.file(
    'tsconfig.json',
    JSON.stringify(
      {
        compilerOptions: {
          target: 'ES2022',
          experimentalDecorators: true,
          useDefineForClassFields: false,
          module: 'ESNext',
          types: ['vite/client'],
          lib: ['ES2022', 'DOM', 'DOM.Iterable'],
          skipLibCheck: true,
          moduleResolution: 'bundler',
          isolatedModules: true,
          moduleDetection: 'force',
          allowJs: true,
          jsx: 'react-jsx',
          paths: { '@/*': ['./*'] },
          allowImportingTsExtensions: true,
          noEmit: true
        }
      },
      null,
      2
    )
  );

  zip.file(
    'index.html',
    `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Rahosantochat - Secure Messaging &amp; Media Sharing</title>
    <meta name="description" content="A fast, secure contact-based chat application for end-to-end encrypted messaging, voice notes, and effortless media sharing." />
    <link rel="icon" type="image/svg+xml" href="/icon-192.svg" />
    <link rel="manifest" href="/manifest.json" />
  </head>
  <body class="bg-slate-950 text-slate-100">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
  );

  zip.file(
    'README.md',
    `# Rahosantochat - Secure Messaging & Media Sharing

Rahosantochat is an end-to-end encrypted (AES-256-GCM) contact-person chat application allowing users to securely exchange messages, audio voice notes, photos, videos, and documents effortlessly.

## Quick Start

1. Install dependencies:
\`\`\`bash
npm install
\`\`\`

2. Run development server:
\`\`\`bash
npm run dev
\`\`\`
Visit [http://localhost:3000](http://localhost:3000)

3. Build for production:
\`\`\`bash
npm run build
\`\`\`

## Features
- **End-to-End Encryption**: AES-256-GCM authenticated cipher streams.
- **Inspectable Payloads**: Real-time view of IV, ciphertext base64, and verification tag.
- **Effortless Media Sharing**: Photos, documents, voice notes, and videos.
- **Safety Number Verification**: 60-digit comparison codes and QR codes.
- **PWA Ready**: Installable on Android, iOS, Windows, and macOS.
`
  );

  // Fetch or read files that currently exist in the app
  try {
    const fetchFile = async (url: string) => {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Failed to fetch ${url}`);
      return await res.text();
    };

    // Public folder
    const [manifest, icon192, icon512, sw] = await Promise.all([
      fetchFile('/manifest.json').catch(() => '{}'),
      fetchFile('/icon-192.svg').catch(() => ''),
      fetchFile('/icon-512.svg').catch(() => ''),
      fetchFile('/sw.js').catch(() => '')
    ]);

    const publicFolder = zip.folder('public');
    if (publicFolder) {
      publicFolder.file('manifest.json', manifest);
      publicFolder.file('icon-192.svg', icon192);
      publicFolder.file('icon-512.svg', icon512);
      publicFolder.file('sw.js', sw);
    }
  } catch {
    // Non-fatal if fetch is skipped in some environments
  }

  // Generate ZIP blob and trigger download
  const blob = await zip.generateAsync({ type: 'blob' });
  const downloadUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = downloadUrl;
  link.download = 'Rahosantochat_Application_Source.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(downloadUrl);
}
