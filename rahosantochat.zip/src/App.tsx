import React, { useState, useEffect } from 'react';
import { Lock } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { ChatHeader } from './components/ChatHeader';
import { MessageList } from './components/MessageList';
import { MessageInput } from './components/MessageInput';
import { ContactDrawer } from './components/ContactDrawer';
import { MediaLightbox } from './components/MediaLightbox';
import { SafetyVerificationModal } from './components/SafetyVerificationModal';
import { CipherInspectorModal } from './components/CipherInspectorModal';
import { CallModal } from './components/CallModal';
import { NewContactModal } from './components/NewContactModal';
import { CameraCaptureModal } from './components/CameraCaptureModal';
import { DownloadAppModal } from './components/DownloadAppModal';
import { SyncContactsModal } from './components/SyncContactsModal';
import { StatusViewerModal } from './components/StatusViewerModal';
import { SettingsModal } from './components/SettingsModal';
import { Contact, Message, MediaAttachment, MessageReplyInfo, StatusStory } from './types/chat';
import { INITIAL_CONTACTS, INITIAL_MESSAGES, INITIAL_STORIES } from './utils/initialData';
import { encryptMessage } from './utils/crypto';

export default function App() {
  // Load state from localStorage or initial defaults
  const [contacts, setContacts] = useState<Contact[]>(() => {
    const saved = localStorage.getItem('rahosantochat_contacts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_CONTACTS;
      }
    }
    return INITIAL_CONTACTS;
  });

  const [messages, setMessages] = useState<Record<string, Message[]>>(() => {
    const saved = localStorage.getItem('rahosantochat_messages');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_MESSAGES;
      }
    }
    return INITIAL_MESSAGES;
  });

  const [stories, setStories] = useState<StatusStory[]>(() => {
    const saved = localStorage.getItem('rahosantochat_stories');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_STORIES;
      }
    }
    return INITIAL_STORIES;
  });

  const [activeContactId, setActiveContactId] = useState<string>('santo-rahman');
  const [currentUser, setCurrentUser] = useState<{
    id: string;
    name: string;
    handle: string;
    avatar: string;
    status: string;
  }>(() => {
    const saved = localStorage.getItem('rahosantochat_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // default
      }
    }
    return {
      id: 'me',
      name: 'Rahotma',
      handle: '@rahotma',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      status: 'online'
    };
  });

  // Mobile navigation state
  const [isMobileView, setIsMobileView] = useState(false);
  const [showMobileChat, setShowMobileChat] = useState(false);

  // Search inside current chat
  const [searchInChat, setSearchInChat] = useState('');
  const [isSearchingInChat, setIsSearchingInChat] = useState(false);

  // Replying state
  const [replyingTo, setReplyingTo] = useState<MessageReplyInfo | null>(null);

  // Modals & Drawer states
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [lightboxMedia, setLightboxMedia] = useState<MediaAttachment | null>(null);
  const [inspectingMessage, setInspectingMessage] = useState<Message | null>(null);
  const [isSafetyModalOpen, setIsSafetyModalOpen] = useState(false);
  const [isNewContactModalOpen, setIsNewContactModalOpen] = useState(false);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isStoryViewerOpen, setIsStoryViewerOpen] = useState(false);
  const [activeStoryIndex, setActiveStoryIndex] = useState(0);

  const [callSession, setCallSession] = useState<{
    isOpen: boolean;
    type: 'audio' | 'video';
  }>({
    isOpen: false,
    type: 'audio'
  });

  // Responsive mobile screen check
  useEffect(() => {
    const checkMobile = () => {
      setIsMobileView(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Theme state: defaults to 'light' (white background)
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('rahosantochat_theme');
    return saved === 'dark' ? 'dark' : 'light';
  });

  useEffect(() => {
    localStorage.setItem('rahosantochat_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('rahosantochat_contacts', JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem('rahosantochat_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('rahosantochat_stories', JSON.stringify(stories));
  }, [stories]);

  useEffect(() => {
    localStorage.setItem('rahosantochat_user', JSON.stringify(currentUser));
  }, [currentUser]);

  // Active contact object
  const activeContact = contacts.find((c) => c.id === activeContactId) || contacts[0];
  const activeMessages = messages[activeContact?.id] || [];

  // Switch persona (e.g. test chatting as Rahotma vs Santo Rahman)
  const handleSwitchUser = (userId: string) => {
    if (userId === 'santo-rahman') {
      setCurrentUser({
        id: 'santo-rahman',
        name: 'Santo Rahman',
        handle: '@santorahman',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        status: 'online'
      });
      setActiveContactId('aura-lestari');
    } else {
      setCurrentUser({
        id: 'me',
        name: 'Rahotma',
        handle: '@rahotma',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
        status: 'online'
      });
      setActiveContactId('santo-rahman');
    }
  };

  // Send a message with cryptographic encryption
  const handleSendMessage = async (text: string, mediaFiles?: MediaAttachment[], targetContactId?: string) => {
    const recipientContactId = targetContactId || activeContact?.id;
    if (!recipientContactId) return;

    // Encrypt content via WebCrypto AES-GCM
    const encryptedPayload = await encryptMessage(
      text || (mediaFiles ? `[Media Attachment: ${mediaFiles[0].name}]` : ''),
      recipientContactId
    );

    const newMessage: Message = {
      id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      senderId: 'me',
      recipientId: recipientContactId,
      text,
      timestamp: Date.now(),
      status: 'sent',
      media: mediaFiles,
      encryptedPayload,
      replyTo: replyingTo || undefined
    };

    setMessages((prev) => ({
      ...prev,
      [recipientContactId]: [...(prev[recipientContactId] || []), newMessage]
    }));

    setReplyingTo(null);

    // Simulate delivered & read transitions
    setTimeout(() => {
      setMessages((prev) => {
        const list = prev[recipientContactId] || [];
        return {
          ...prev,
          [recipientContactId]: list.map((m) =>
            m.id === newMessage.id ? { ...m, status: 'delivered' } : m
          )
        };
      });
    }, 800);

    setTimeout(() => {
      setMessages((prev) => {
        const list = prev[recipientContactId] || [];
        return {
          ...prev,
          [recipientContactId]: list.map((m) =>
            m.id === newMessage.id ? { ...m, status: 'read' } : m
          )
        };
      });
    }, 1800);
  };

  // Reply to Status Story
  const handleReplyToStory = (targetContactId: string, replyText: string) => {
    handleSendMessage(replyText, undefined, targetContactId);
    setActiveContactId(targetContactId);
    setShowMobileChat(true);

    // Mark story as viewed
    setStories((prev) =>
      prev.map((s) => (s.contactId === targetContactId ? { ...s, isViewed: true } : s))
    );
  };

  // Simulate contact reply
  const handleSimulateContactReply = async () => {
    if (!activeContact) return;

    const sampleReplies = [
      `Understood Rahotma. I received and decrypted your payload. Security parameters look completely solid.`,
      `Verified the file hash against our local safety numbers. All checks passed with zero discrepancies.`,
      `Everything looks great! Sending over the next set of encrypted diagrams shortly.`,
      `Got it! Let's sync on the secure audio line in 10 minutes if you are free.`
    ];
    const replyText = sampleReplies[Math.floor(Math.random() * sampleReplies.length)];

    const encryptedPayload = await encryptMessage(replyText, activeContact.id);

    const replyMsg: Message = {
      id: `reply-${Date.now()}`,
      senderId: activeContact.id,
      recipientId: 'me',
      text: replyText,
      timestamp: Date.now(),
      status: 'read',
      encryptedPayload
    };

    setMessages((prev) => ({
      ...prev,
      [activeContact.id]: [...(prev[activeContact.id] || []), replyMsg]
    }));
  };

  // Toggle emoji reactions on messages
  const handleToggleReaction = (msgId: string, emoji: string) => {
    if (!activeContact) return;
    setMessages((prev) => {
      const list = prev[activeContact.id] || [];
      return {
        ...prev,
        [activeContact.id]: list.map((m) => {
          if (m.id !== msgId) return m;
          const currentReactions = { ...(m.reactions || {}) };
          const users = currentReactions[emoji] || [];
          if (users.includes('me')) {
            const newUsers = users.filter((u) => u !== 'me');
            if (newUsers.length === 0) {
              delete currentReactions[emoji];
            } else {
              currentReactions[emoji] = newUsers;
            }
          } else {
            currentReactions[emoji] = [...users, 'me'];
          }
          return { ...m, reactions: currentReactions };
        })
      };
    });
  };

  // Toggle starred status
  const handleToggleStar = (msgId: string) => {
    if (!activeContact) return;
    setMessages((prev) => {
      const list = prev[activeContact.id] || [];
      return {
        ...prev,
        [activeContact.id]: list.map((m) =>
          m.id === msgId ? { ...m, isStarred: !m.isStarred } : m
        )
      };
    });
  };

  // Delete message
  const handleDeleteMessage = (msgId: string) => {
    if (!activeContact) return;
    setMessages((prev) => {
      const list = prev[activeContact.id] || [];
      return {
        ...prev,
        [activeContact.id]: list.filter((m) => m.id !== msgId)
      };
    });
  };

  // Clear chat messages
  const handleClearChat = (targetContactId?: string) => {
    const id = targetContactId || activeContact?.id;
    if (!id) return;
    const target = contacts.find((c) => c.id === id);
    const targetName = target ? target.name : 'this contact';

    if (confirm(`Are you sure you want to clear all messages with ${targetName}?`)) {
      setMessages((prev) => ({
        ...prev,
        [id]: []
      }));
    }
  };

  // Delete contact person and conversation
  const handleDeleteContact = (targetContactId: string) => {
    const target = contacts.find((c) => c.id === targetContactId);
    const targetName = target ? target.name : 'this contact';

    if (confirm(`Are you sure you want to delete "${targetName}" and remove this contact person?`)) {
      setContacts((prev) => {
        const remaining = prev.filter((c) => c.id !== targetContactId);
        if (activeContactId === targetContactId) {
          if (remaining.length > 0) {
            setActiveContactId(remaining[0].id);
          } else {
            setActiveContactId('');
          }
        }
        return remaining;
      });

      setMessages((prev) => {
        const updated = { ...prev };
        delete updated[targetContactId];
        return updated;
      });

      setIsDrawerOpen(false);
    }
  };

  // Import / Sync contacts
  const handleImportContacts = (imported: Contact[]) => {
    setContacts((prev) => {
      const existingIds = new Set(prev.map((c) => c.id));
      const existingPhones = new Set(prev.map((c) => c.phone.replace(/[^0-9]/g, '')));
      
      const newItems = imported.filter((c) => {
        const normalizedPhone = c.phone.replace(/[^0-9]/g, '');
        return !existingIds.has(c.id) && (!normalizedPhone || !existingPhones.has(normalizedPhone));
      });
      return [...newItems, ...prev];
    });

    if (imported.length > 0) {
      setActiveContactId(imported[0].id);
      setShowMobileChat(true);
    }
  };

  // Export chat transcript
  const handleExportChat = () => {
    if (!activeContact) return;
    const lines = [
      `=====================================================`,
      `RAHOSANTOCHAT - SECURE END-TO-END TRANSCRIPT`,
      `Contact: ${activeContact.name} (${activeContact.phone})`,
      `Encryption: AES-256-GCM authenticated stream`,
      `Safety Fingerprint: ${activeContact.customPublicKeyFingerprint}`,
      `Exported: ${new Date().toLocaleString()}`,
      `=====================================================\n`
    ];

    activeMessages.forEach((m) => {
      const sender = m.senderId === 'me' ? currentUser.name : activeContact.name;
      const time = new Date(m.timestamp).toLocaleTimeString();
      const mediaNote = m.media ? ` [Attached: ${m.media.map((a) => a.name).join(', ')}]` : '';
      lines.push(`[${time}] ${sender}: ${m.text || ''}${mediaNote}`);
    });

    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Rahosantochat_${activeContact.name.replace(/\s+/g, '_')}_Transcript.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Update contact settings
  const handleUpdateContact = (updated: Partial<Contact>) => {
    if (!activeContact) return;
    setContacts((prev) =>
      prev.map((c) => (c.id === activeContact.id ? { ...c, ...updated } : c))
    );
  };

  // Toggle verified state
  const handleToggleVerify = (contactId: string) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === contactId ? { ...c, isVerified: !c.isVerified } : c))
    );
  };

  // Add new contact
  const handleAddContact = (newContact: Contact) => {
    setContacts((prev) => [newContact, ...prev]);
    setActiveContactId(newContact.id);
    setMessages((prev) => ({
      ...prev,
      [newContact.id]: []
    }));
    setShowMobileChat(true);
  };

  return (
    <div className="flex h-screen w-screen bg-[#ffffff] dark:bg-[#0c1317] font-sans text-[#111b21] dark:text-[#e9edef] overflow-hidden select-none">
      {/* WhatsApp Sidebar (Navigation Rail + Contacts/Updates/Channels Pane) */}
      <div
        className={`${
          isMobileView && showMobileChat ? 'hidden' : 'flex'
        } w-full md:w-auto h-full flex-shrink-0`}
      >
        <Sidebar
          contacts={contacts}
          activeContactId={activeContactId}
          onSelectContact={(id) => {
            setActiveContactId(id);
            setShowMobileChat(true);
          }}
          messages={messages}
          stories={stories}
          onOpenStoryViewer={(idx) => {
            setActiveStoryIndex(idx);
            setIsStoryViewerOpen(true);
          }}
          onOpenNewContact={() => setIsNewContactModalOpen(true)}
          onOpenDownloadApp={() => setIsDownloadModalOpen(true)}
          onOpenSyncContacts={() => setIsSyncModalOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onDeleteContact={handleDeleteContact}
          onClearChat={handleClearChat}
          currentUser={currentUser}
          onSwitchUser={handleSwitchUser}
          theme={theme}
          onToggleTheme={handleToggleTheme}
        />
      </div>

      {/* Main WhatsApp Chat Conversation View */}
      <main
        className={`${
          isMobileView && !showMobileChat ? 'hidden' : 'flex'
        } flex-1 flex flex-col h-full bg-[#ffffff] dark:bg-[#0b141a] relative min-w-0`}
      >
        {activeContact ? (
          <>
            <ChatHeader
              contact={activeContact}
              onBack={() => setShowMobileChat(false)}
              onOpenSafetyVerification={() => setIsSafetyModalOpen(true)}
              onStartCall={(type) => setCallSession({ isOpen: true, type })}
              onToggleDrawer={() => setIsDrawerOpen(!isDrawerOpen)}
              searchInChat={searchInChat}
              onSearchInChatChange={setSearchInChat}
              isSearching={isSearchingInChat}
              setIsSearching={setIsSearchingInChat}
              onSimulateContactReply={handleSimulateContactReply}
              onClearChat={() => handleClearChat(activeContact.id)}
              onDeleteContact={() => handleDeleteContact(activeContact.id)}
              theme={theme}
              onToggleTheme={handleToggleTheme}
            />

            <MessageList
              messages={activeMessages}
              contact={activeContact}
              onOpenSafetyVerification={() => setIsSafetyModalOpen(true)}
              onOpenLightbox={(media) => setLightboxMedia(media)}
              onInspectPayload={(msg) => setInspectingMessage(msg)}
              onReplyMessage={(msg) =>
                setReplyingTo({
                  id: msg.id,
                  senderName: msg.senderId === 'me' ? currentUser.name : activeContact.name,
                  text: msg.text,
                  mediaType: msg.media && msg.media[0] ? msg.media[0].type : undefined
                })
              }
              onToggleReaction={handleToggleReaction}
              onToggleStar={handleToggleStar}
              onDeleteMessage={handleDeleteMessage}
              searchQuery={searchInChat}
            />

            <MessageInput
              onSendMessage={handleSendMessage}
              replyingTo={replyingTo}
              onCancelReply={() => setReplyingTo(null)}
              onOpenLiveCamera={() => setIsCameraModalOpen(true)}
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#f0f2f5] dark:bg-[#222e35] border-b-[6px] border-[#00a884] select-none text-[#111b21] dark:text-[#e9edef]">
            <div className="w-56 h-48 mb-6 opacity-75 flex items-center justify-center">
              <svg viewBox="0 0 300 200" className="w-full h-full text-[#667781] dark:text-[#8696a0] fill-current">
                <rect x="20" y="30" width="180" height="110" rx="8" fill="none" stroke="currentColor" strokeWidth="4" />
                <rect x="30" y="40" width="160" height="90" rx="4" fill={theme === 'dark' ? '#182229' : '#e9edef'} />
                <path d="M 90 140 L 130 140 L 140 160 L 80 160 Z" fill="currentColor" />
                <rect x="60" y="160" width="100" height="6" rx="3" fill="currentColor" />
                <rect x="170" y="70" width="60" height="100" rx="10" fill={theme === 'dark' ? '#111b21' : '#ffffff'} stroke="currentColor" strokeWidth="3" />
                <circle cx="200" cy="155" r="4" fill="currentColor" />
                <line x1="190" y1="80" x2="210" y2="80" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>

            <h2 className="text-3xl font-light text-[#111b21] dark:text-[#e9edef] mb-3">WhatsApp Web</h2>
            <p className="text-sm text-[#667781] dark:text-[#8696a0] max-w-md leading-relaxed mb-6">
              Send and receive end-to-end encrypted messages and effortlessly share media files on your phone, tablet, and computer.
            </p>

            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="px-6 py-2.5 rounded-full bg-[#00a884] hover:bg-[#02906f] text-white font-semibold text-sm transition-transform active:scale-95 shadow-md flex items-center gap-2"
            >
              <span>Download &amp; Install WhatsApp Applet</span>
            </button>

            <div className="mt-14 text-xs text-[#667781] dark:text-[#8696a0] flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>End-to-end encrypted</span>
            </div>
          </div>
        )}

        {/* Contact Drawer Panel */}
        {activeContact && (
          <ContactDrawer
            contact={activeContact}
            isOpen={isDrawerOpen}
            onClose={() => setIsDrawerOpen(false)}
            messages={activeMessages}
            onOpenSafetyVerification={() => setIsSafetyModalOpen(true)}
            onOpenLightbox={(media) => setLightboxMedia(media)}
            onUpdateContact={handleUpdateContact}
            onClearChat={() => handleClearChat(activeContact.id)}
            onDeleteContact={() => handleDeleteContact(activeContact.id)}
            onExportChat={handleExportChat}
          />
        )}
      </main>

      {/* Media Lightbox Viewer */}
      <MediaLightbox
        media={lightboxMedia}
        onClose={() => setLightboxMedia(null)}
      />

      {/* WhatsApp Status Story Viewer Modal */}
      <StatusViewerModal
        stories={stories}
        initialIndex={activeStoryIndex}
        isOpen={isStoryViewerOpen}
        onClose={() => setIsStoryViewerOpen(false)}
        onReplyToStory={handleReplyToStory}
      />

      {/* WhatsApp Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentUser={currentUser}
        onUpdateCurrentUser={(updated) => setCurrentUser((prev) => ({ ...prev, ...updated }))}
        onOpenSyncContacts={() => setIsSyncModalOpen(true)}
        onOpenDownloadApp={() => setIsDownloadModalOpen(true)}
        onSwitchUser={handleSwitchUser}
        theme={theme}
        onToggleTheme={handleToggleTheme}
      />

      {/* Safety Verification Modal (60 digits + QR) */}
      <SafetyVerificationModal
        contact={activeContact}
        isOpen={isSafetyModalOpen}
        onClose={() => setIsSafetyModalOpen(false)}
        onToggleVerify={handleToggleVerify}
      />

      {/* Cryptographic Cipher Inspector Modal */}
      <CipherInspectorModal
        message={inspectingMessage}
        isOpen={!!inspectingMessage}
        onClose={() => setInspectingMessage(null)}
      />

      {/* Audio / Video Encrypted Call Modal */}
      <CallModal
        contact={activeContact}
        callType={callSession.type}
        isOpen={callSession.isOpen}
        onEndCall={() => setCallSession({ isOpen: false, type: 'audio' })}
      />

      {/* Add New Contact Modal */}
      <NewContactModal
        isOpen={isNewContactModalOpen}
        onClose={() => setIsNewContactModalOpen(false)}
        onAddContact={handleAddContact}
      />

      {/* Instant Webcam Photo Snapshot Modal */}
      <CameraCaptureModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        onPhotoCaptured={(attachment) => {
          handleSendMessage('', [attachment]);
        }}
      />

      {/* Download Application & PWA Installation Modal */}
      <DownloadAppModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* Sync Original Contacts Modal (Phonebook / vCard / CSV) */}
      <SyncContactsModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
        onImportContacts={handleImportContacts}
      />
    </div>
  );
}
