import React, { useState } from 'react';
import { X, UserPlus, ShieldCheck } from 'lucide-react';
import { Contact } from '../types/chat';
import { formatSafetyNumber } from '../utils/crypto';

interface NewContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddContact: (contact: Contact) => void;
}

const SAMPLE_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80'
];

export const NewContactModal: React.FC<NewContactModalProps> = ({
  isOpen,
  onClose,
  onAddContact
}) => {
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('Colleague');
  const [selectedAvatar, setSelectedAvatar] = useState(SAMPLE_AVATARS[0]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const contactId = `contact-${Date.now()}`;
    const safetyNumber = formatSafetyNumber(contactId + (phone || name)).join(' ');

    const newContact: Contact = {
      id: contactId,
      name: name.trim(),
      handle: handle.startsWith('@') ? handle : `@${handle || name.toLowerCase().replace(/\s+/g, '_')}`,
      phone: phone || '+62 812-0000-1111',
      email: email || `${name.toLowerCase().replace(/\s+/g, '.')}@rahosanto.net`,
      role: role || 'Contact Person',
      avatar: selectedAvatar,
      avatarColor: 'from-emerald-500 to-teal-700',
      status: 'online',
      lastSeen: 'Active now',
      safetyNumber,
      isVerified: true,
      isPinned: false,
      isMuted: false,
      isBlocked: false,
      disappearingTimer: 0,
      customPublicKeyFingerprint: `SHA256:${Array.from({ length: 8 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0').toUpperCase()).join(':')}`
    };

    onAddContact(newContact);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150 select-none">
      <div className="w-full max-w-md bg-white dark:bg-[#111b21] border border-[#e9edef] dark:border-[#222d34] rounded-2xl shadow-2xl overflow-hidden flex flex-col text-[#111b21] dark:text-[#e9edef] transition-colors">
        {/* Header */}
        <div className="p-4 border-b border-[#e9edef] dark:border-[#222d34] flex items-center justify-between bg-[#f0f2f5] dark:bg-[#202c33]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#00a884]/15 text-[#00a884] rounded-lg">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">Add New Contact</h3>
              <p className="text-xs text-[#667781] dark:text-[#8696a0]">Establish end-to-end encrypted connection</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-white hover:bg-gray-200 dark:hover:bg-[#374248]/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Avatar selector */}
          <div>
            <label className="block text-xs font-semibold text-[#667781] dark:text-[#8696a0] mb-2">
              Select Avatar
            </label>
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {SAMPLE_AVATARS.map((url, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => setSelectedAvatar(url)}
                  className={`w-12 h-12 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                    selectedAvatar === url
                      ? 'border-[#00a884] scale-105 shadow-md'
                      : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={url} alt="Avatar" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#667781] dark:text-[#8696a0] mb-1">
              Full Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Santo Rahman"
              className="w-full bg-[#f0f2f5] dark:bg-[#202c33] text-sm text-[#111b21] dark:text-[#e9edef] placeholder-[#667781] dark:placeholder-[#8696a0] rounded-lg px-3 py-2 border border-[#e9edef] dark:border-[#222d34] focus:outline-none focus:border-[#00a884]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#667781] dark:text-[#8696a0] mb-1">
                Username / Handle
              </label>
              <input
                type="text"
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                placeholder="@santorahman"
                className="w-full bg-[#f0f2f5] dark:bg-[#202c33] text-sm text-[#111b21] dark:text-[#e9edef] placeholder-[#667781] dark:placeholder-[#8696a0] rounded-lg px-3 py-2 border border-[#e9edef] dark:border-[#222d34] focus:outline-none focus:border-[#00a884]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#667781] dark:text-[#8696a0] mb-1">
                Role / Title
              </label>
              <input
                type="text"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                placeholder="Architect, Designer..."
                className="w-full bg-[#f0f2f5] dark:bg-[#202c33] text-sm text-[#111b21] dark:text-[#e9edef] placeholder-[#667781] dark:placeholder-[#8696a0] rounded-lg px-3 py-2 border border-[#e9edef] dark:border-[#222d34] focus:outline-none focus:border-[#00a884]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#667781] dark:text-[#8696a0] mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+62 812-3456-7890"
              className="w-full bg-[#f0f2f5] dark:bg-[#202c33] text-sm text-[#111b21] dark:text-[#e9edef] placeholder-[#667781] dark:placeholder-[#8696a0] rounded-lg px-3 py-2 border border-[#e9edef] dark:border-[#222d34] focus:outline-none focus:border-[#00a884]"
            />
          </div>

          <div className="p-3 bg-[#00a884]/10 rounded-xl border border-[#00a884]/20 text-xs text-[#008069] dark:text-[#00a884] flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#00a884] shrink-0" />
            <span>A 256-bit cryptographic key pair will be provisioned automatically.</span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-white rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold bg-[#00a884] hover:bg-[#02906f] text-white rounded-lg transition-colors shadow-md"
            >
              Add Contact &amp; Start Chat
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
