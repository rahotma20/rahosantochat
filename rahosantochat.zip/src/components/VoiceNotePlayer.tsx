import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Mic } from 'lucide-react';
import { formatDuration } from '../utils/crypto';

interface VoiceNotePlayerProps {
  url: string;
  duration?: number;
  isMe: boolean;
}

export const VoiceNotePlayer: React.FC<VoiceNotePlayerProps> = ({
  url,
  duration = 30,
  isMe
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Deterministic waveform bars
  const waveBars = React.useMemo(() => {
    let seed = 42;
    for (let i = 0; i < url.length; i++) {
      seed = (seed * 31 + url.charCodeAt(i)) % 1000;
    }
    const bars: number[] = [];
    for (let i = 0; i < 30; i++) {
      const height = 20 + (((seed + i * 37) % 80));
      bars.push(height);
    }
    return bars;
  }, [url]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.playbackRate = playbackRate;
      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(() => {
          // Fallback simulation
          setIsPlaying(true);
          const timer = setInterval(() => {
            setCurrentTime((prev) => {
              if (prev >= duration) {
                clearInterval(timer);
                setIsPlaying(false);
                return 0;
              }
              return prev + 0.5;
            });
          }, 500);
        });
    }
  };

  const cyclePlaybackRate = () => {
    const nextRate = playbackRate === 1 ? 1.5 : playbackRate === 1.5 ? 2 : 1;
    setPlaybackRate(nextRate);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextRate;
    }
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="flex items-center gap-3 py-1 px-1 min-w-[240px] max-w-sm select-none">
      <audio ref={audioRef} src={url} preload="metadata" />

      {/* WhatsApp Voice Note Play/Pause Circular Button */}
      <button
        type="button"
        onClick={togglePlay}
        className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-transparent text-[#8696a0] hover:text-[#00a884] transition-transform active:scale-95"
      >
        {isPlaying ? (
          <Pause className="w-6 h-6 fill-current text-[#00a884]" />
        ) : (
          <Play className="w-6 h-6 fill-current ml-0.5 text-[#00a884]" />
        )}
      </button>

      {/* Waveform & Scrubber Dot */}
      <div className="flex-1 flex flex-col gap-1.5">
        <div className="relative flex items-center gap-[2.5px] h-7 cursor-pointer overflow-hidden">
          {waveBars.map((bar, idx) => {
            const barProgress = (idx / waveBars.length) * 100;
            const isFilled = barProgress <= progressPercent;
            return (
              <span
                key={idx}
                style={{ height: `${bar}%` }}
                className={`w-[3px] rounded-full transition-colors duration-75 ${
                  isFilled
                    ? 'bg-[#00a884]'
                    : isMe
                    ? 'bg-[#8696a0]/40'
                    : 'bg-[#8696a0]/30'
                }`}
              />
            );
          })}
        </div>

        {/* Timers & WhatsApp Speed Button */}
        <div className="flex items-center justify-between text-[11px] text-[#8696a0] font-sans">
          <span>{formatDuration(currentTime > 0 ? currentTime : duration)}</span>
          <button
            type="button"
            onClick={cyclePlaybackRate}
            className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-[#111b21]/40 text-[#8696a0] hover:text-[#e9edef] transition-colors"
          >
            {playbackRate}x
          </button>
        </div>
      </div>

      {/* Small Mic Badge on right (WhatsApp style) */}
      <div className="relative shrink-0 pr-1">
        <div className="w-6 h-6 rounded-full bg-[#00a884]/20 flex items-center justify-center text-[#00a884]">
          <Mic className="w-3.5 h-3.5" />
        </div>
      </div>
    </div>
  );
};
