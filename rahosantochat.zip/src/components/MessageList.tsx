import React, { useRef, useEffect } from 'react';
import { 
  ShieldCheck, 
  Check, 
  CheckCheck, 
  Lock, 
  CornerUpLeft, 
  Smile, 
  Star, 
  Trash2, 
  Download, 
  FileText, 
  Eye, 
  Code2, 
  ChevronDown
} from 'lucide-react';
import { Contact, Message, MediaAttachment } from '../types/chat';
import { formatTime, formatMessageDate, formatBytes } from '../utils/crypto';
import { VoiceNotePlayer } from './VoiceNotePlayer';

interface MessageListProps {
  messages: Message[];
  contact: Contact;
  onOpenSafetyVerification: () => void;
  onOpenLightbox: (media: MediaAttachment) => void;
  onInspectPayload: (msg: Message) => void;
  onReplyMessage: (msg: Message) => void;
  onToggleReaction: (msgId: string, emoji: string) => void;
  onToggleStar: (msgId: string) => void;
  onDeleteMessage: (msgId: string) => void;
  searchQuery: string;
}

const COMMON_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

export const MessageList: React.FC<MessageListProps> = ({
  messages,
  contact,
  onOpenSafetyVerification,
  onOpenLightbox,
  onInspectPayload,
  onReplyMessage,
  onToggleReaction,
  onToggleStar,
  onDeleteMessage,
  searchQuery
}) => {
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const [activeActionMenuMsgId, setActiveActionMenuMsgId] = React.useState<string | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  // Group messages by date
  const groupedMessages: { date: string; msgs: Message[] }[] = [];
  messages.forEach((msg) => {
    const dateStr = formatMessageDate(msg.timestamp);
    const lastGroup = groupedMessages[groupedMessages.length - 1];
    if (lastGroup && lastGroup.date === dateStr) {
      lastGroup.msgs.push(msg);
    } else {
      groupedMessages.push({ date: dateStr, msgs: [msg] });
    }
  });

  const highlightMatches = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <mark key={i} className="bg-emerald-300 dark:bg-[#00a884]/40 text-[#111b21] dark:text-[#53bdeb] font-semibold px-0.5 rounded">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-12 py-3 space-y-2 wa-chat-bg">
      {/* WhatsApp End-to-End Encryption Banner */}
      <div className="max-w-md mx-auto my-3 text-center">
        <button
          onClick={onOpenSafetyVerification}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#ffeecd] dark:bg-[#182229] border border-[#f0e0b0] dark:border-[#222d34] text-[12px] text-[#54656f] dark:text-[#ffd279] shadow-xs text-center hover:bg-[#fae7be] dark:hover:bg-[#202c33] transition-colors"
        >
          <Lock className="w-3.5 h-3.5 text-amber-600 dark:text-[#ffd279] shrink-0 inline mr-0.5" />
          <span>
            Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to verify.
          </span>
        </button>
      </div>

      {groupedMessages.map((group) => (
        <div key={group.date} className="space-y-1.5">
          {/* WhatsApp Date Separator Pill */}
          <div className="flex items-center justify-center my-3">
            <span className="text-[12px] font-medium text-[#54656f] dark:text-[#8696a0] bg-white dark:bg-[#182229] px-3 py-1 rounded-lg shadow-xs border border-[#e9edef] dark:border-[#222d34]">
              {group.date.toUpperCase()}
            </span>
          </div>

          {/* Messages in Date Group */}
          {group.msgs.map((msg, idx) => {
            const isMe = msg.senderId === 'me';
            const isMatch = searchQuery && msg.text.toLowerCase().includes(searchQuery.toLowerCase());
            const hasTail = idx === 0 || group.msgs[idx - 1].senderId !== msg.senderId;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} group relative select-text`}
              >
                {/* Replying Quote Context */}
                {msg.replyTo && (
                  <div
                    className={`max-w-md mb-1 px-2.5 py-1.5 rounded-md text-xs border-l-4 shadow-2xs ${
                      isMe
                        ? 'bg-[#c3f4bc] dark:bg-[#025144] border-[#00a884] text-[#111b21] dark:text-[#d1d7db]'
                        : 'bg-[#f0f2f5] dark:bg-[#182229] border-[#00a884] dark:border-[#53bdeb] text-[#111b21] dark:text-[#d1d7db]'
                    } flex flex-col ${isMe ? 'mr-1' : 'ml-1'}`}
                  >
                    <span className="font-semibold text-[#00a884] text-[11px]">
                      {msg.replyTo.senderName}
                    </span>
                    <span className="truncate text-[#667781] dark:text-[#8696a0]">
                      {msg.replyTo.text || (msg.replyTo.mediaType ? `[${msg.replyTo.mediaType.toUpperCase()}]` : '')}
                    </span>
                  </div>
                )}

                {/* WhatsApp Message Bubble */}
                <div
                  className={`relative max-w-[85%] sm:max-w-[70%] md:max-w-[65%] rounded-lg p-2.5 shadow-xs text-sm transition-all ${
                    isMe
                      ? `bg-[#d9fdd3] dark:bg-[#005c4b] text-[#111b21] dark:text-[#e9edef] ${hasTail ? 'wa-bubble-tail-out rounded-tr-none' : ''}`
                      : `bg-white dark:bg-[#202c33] text-[#111b21] dark:text-[#e9edef] border border-gray-100/80 dark:border-transparent ${hasTail ? 'wa-bubble-tail-in rounded-tl-none' : ''}`
                  } ${isMatch ? 'ring-2 ring-[#00a884]' : ''}`}
                >
                  {/* Sender Name in group or chat */}
                  {!isMe && (
                    <div className="text-[12px] font-semibold text-[#00a884] mb-0.5">
                      {contact.name}
                    </div>
                  )}

                  {/* Media Content */}
                  {msg.media && msg.media.length > 0 && (
                    <div className="space-y-1.5 mb-1.5">
                      {msg.media.map((med) => (
                        <div key={med.id} className="rounded-lg overflow-hidden">
                          {med.type === 'image' && (
                            <div className="relative group/media overflow-hidden rounded-lg bg-black/5 dark:bg-[#0b141a]">
                              <img
                                src={med.url}
                                alt={med.name}
                                className="w-full max-h-80 object-cover rounded-lg cursor-pointer hover:opacity-95 transition-opacity"
                                onClick={() => onOpenLightbox(med)}
                              />
                              <div className="absolute top-2 right-2 flex items-center gap-1 opacity-0 group-hover/media:opacity-100 transition-opacity bg-black/60 rounded-md p-1">
                                <button
                                  onClick={() => onOpenLightbox(med)}
                                  className="p-1 hover:text-[#00a884] text-white"
                                  title="View photo"
                                >
                                  <Eye className="w-4 h-4" />
                                </button>
                                <a
                                  href={med.url}
                                  download={med.name}
                                  className="p-1 hover:text-[#00a884] text-white"
                                  title="Download photo"
                                >
                                  <Download className="w-4 h-4" />
                                </a>
                              </div>
                            </div>
                          )}

                          {med.type === 'audio' && (
                            <VoiceNotePlayer
                              url={med.url}
                              duration={med.duration || 30}
                              isMe={isMe}
                            />
                          )}

                          {med.type === 'document' && (
                            <div
                              className={`p-3 rounded-lg flex items-center justify-between gap-3 ${
                                isMe ? 'bg-[#c3f4bc]/70 dark:bg-[#025144]' : 'bg-[#f0f2f5] dark:bg-[#182229]'
                              }`}
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <div className="p-2 bg-[#00a884]/20 text-[#00a884] rounded-lg">
                                  <FileText className="w-5 h-5" />
                                </div>
                                <div className="min-w-0 text-left">
                                  <p className="text-xs font-medium truncate text-[#111b21] dark:text-[#e9edef]">
                                    {med.name}
                                  </p>
                                  <p className="text-[11px] text-[#667781] dark:text-[#8696a0]">
                                    {formatBytes(med.size)}
                                  </p>
                                </div>
                              </div>
                              <a
                                href={med.url}
                                download={med.name}
                                className="p-1.5 text-[#667781] dark:text-[#8696a0] hover:text-[#00a884] rounded-full shrink-0"
                                title="Download Document"
                              >
                                <Download className="w-4 h-4" />
                              </a>
                            </div>
                          )}

                          {med.type === 'video' && (
                            <div className="rounded-lg overflow-hidden bg-black">
                              <video
                                src={med.url}
                                controls
                                className="w-full max-h-80 rounded-lg"
                              />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Text Message */}
                  {msg.text && (
                    <p className="text-[14.2px] leading-[19px] whitespace-pre-wrap break-words pr-2">
                      {highlightMatches(msg.text, searchQuery)}
                    </p>
                  )}

                  {/* WhatsApp Time & Checkmarks footer */}
                  <div className="flex items-center justify-end gap-1 mt-1 text-[11px] text-[#667781] dark:text-[#8696a0] leading-none select-none">
                    {/* E2EE Lock inspection icon */}
                    <button
                      type="button"
                      onClick={() => onInspectPayload(msg)}
                      title="End-to-end encrypted (AES-256-GCM). Click to view details."
                      className="hover:text-[#111b21] dark:hover:text-[#e9edef] transition-colors"
                    >
                      <Lock className="w-2.5 h-2.5" />
                    </button>

                    <span>{formatTime(msg.timestamp)}</span>

                    {msg.isStarred && (
                      <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                    )}

                    {/* WhatsApp Read Receipt Icons */}
                    {isMe && (
                      <span>
                        {msg.status === 'sending' ? (
                          <span className="w-2.5 h-2.5 rounded-full border border-[#667781] dark:border-[#8696a0] border-t-transparent animate-spin inline-block" />
                        ) : msg.status === 'sent' ? (
                          <Check className="w-3.5 h-3.5 text-[#667781] dark:text-[#8696a0]" />
                        ) : msg.status === 'delivered' ? (
                          <CheckCheck className="w-3.5 h-3.5 text-[#667781] dark:text-[#8696a0]" />
                        ) : (
                          <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb] font-bold" />
                        )}
                      </span>
                    )}
                  </div>
                </div>

                {/* Reaction Pill Badges under the bubble */}
                {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                  <div
                    className={`flex flex-wrap gap-1 -mt-2 ${
                      isMe ? 'justify-end mr-2' : 'justify-start ml-2'
                    } z-10`}
                  >
                    {Object.entries(msg.reactions).map(([emoji, users]) => {
                      const hasReacted = users.includes('me');
                      return (
                        <button
                          key={emoji}
                          onClick={() => onToggleReaction(msg.id, emoji)}
                          className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-xs shadow-xs border ${
                            hasReacted
                              ? 'bg-[#d9fdd3] dark:bg-[#005c4b] border-[#00a884] text-[#008069] dark:text-white font-medium'
                              : 'bg-white dark:bg-[#202c33] border-[#e9edef] dark:border-[#222d34] text-[#111b21] dark:text-[#e9edef] hover:border-[#00a884]'
                          }`}
                        >
                          <span>{emoji}</span>
                          <span className="text-[10px] font-semibold text-[#667781] dark:text-[#8696a0]">
                            {users.length}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* WhatsApp Hover Quick Actions Chevron */}
                <div
                  className={`absolute top-1 opacity-0 group-hover:opacity-100 transition-opacity z-10 ${
                    isMe ? 'right-2' : 'left-2'
                  }`}
                >
                  <div className="relative">
                    <button
                      onClick={() =>
                        setActiveActionMenuMsgId(
                          activeActionMenuMsgId === msg.id ? null : msg.id
                        )
                      }
                      className="p-1 rounded bg-white/95 dark:bg-[#202c33]/80 hover:bg-white dark:hover:bg-[#202c33] text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] shadow-md border border-gray-200/60 dark:border-transparent"
                      title="Message menu"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>

                    {activeActionMenuMsgId === msg.id && (
                      <div className="absolute right-0 top-full mt-1 w-44 bg-white dark:bg-[#233138] border border-[#e9edef] dark:border-[#222d34] rounded-xl shadow-2xl py-1 z-30 text-xs text-[#111b21] dark:text-[#d1d7db] animate-in fade-in zoom-in-95 duration-100">
                        {/* Quick Reactions bar */}
                        <div className="px-2 py-1 flex items-center justify-between border-b border-[#e9edef] dark:border-[#2a3942] mb-1">
                          {COMMON_EMOJIS.map((emoji) => (
                            <button
                              key={emoji}
                              onClick={() => {
                                onToggleReaction(msg.id, emoji);
                                setActiveActionMenuMsgId(null);
                              }}
                              className="text-base hover:scale-125 transition-transform"
                            >
                              {emoji}
                            </button>
                          ))}
                        </div>

                        <button
                          onClick={() => {
                            onReplyMessage(msg);
                            setActiveActionMenuMsgId(null);
                          }}
                          className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors"
                        >
                          <CornerUpLeft className="w-3.5 h-3.5 text-[#00a884]" />
                          <span>Reply</span>
                        </button>

                        <button
                          onClick={() => {
                            onToggleStar(msg.id);
                            setActiveActionMenuMsgId(null);
                          }}
                          className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors"
                        >
                          <Star className="w-3.5 h-3.5 text-amber-500" />
                          <span>{msg.isStarred ? 'Unstar message' : 'Star message'}</span>
                        </button>

                        <button
                          onClick={() => {
                            onInspectPayload(msg);
                            setActiveActionMenuMsgId(null);
                          }}
                          className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors"
                        >
                          <Code2 className="w-3.5 h-3.5 text-cyan-500" />
                          <span>Inspect cipher</span>
                        </button>

                        <button
                          onClick={() => {
                            onDeleteMessage(msg.id);
                            setActiveActionMenuMsgId(null);
                          }}
                          className="w-full px-3 py-1.5 text-left flex items-center gap-2 text-rose-600 dark:text-rose-400 hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete message</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ))}
      <div ref={messagesEndRef} />
    </div>
  );
};
