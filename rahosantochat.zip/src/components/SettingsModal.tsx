import React, { useState } from 'react';
import { 
  X, 
  User, 
  Lock, 
  MessageSquare, 
  ShieldCheck, 
  Download, 
  RefreshCw, 
  Copy, 
  Check, 
  Moon, 
  Sun,
  Smartphone, 
  ChevronRight,
  Palette
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: {
    id: string;
    name: string;
    handle: string;
    avatar: string;
    status: string;
  };
  onUpdateCurrentUser: (updated: { name: string; handle: string }) => void;
  onOpenSyncContacts: () => void;
  onOpenDownloadApp: () => void;
  onSwitchUser: (userId: string) => void;
  theme?: 'light' | 'dark';
  onToggleTheme?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateCurrentUser,
  onOpenSyncContacts,
  onOpenDownloadApp,
  onSwitchUser,
  theme = 'light',
  onToggleTheme
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'privacy' | 'chats' | 'app'>('profile');
  const [name, setName] = useState(currentUser.name);
  const [about, setAbout] = useState('Hey there! I am using Rahosantochat.');
  const [copiedLink, setCopiedLink] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  if (!isOpen) return null;

  const appUrl = typeof window !== 'undefined' && window.location.origin
    ? window.location.origin
    : 'https://ais-pre-w7nmsuf6m34trgg6xtio22-322320475282.asia-southeast1.run.app';

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateCurrentUser({
      name: name.trim() || currentUser.name,
      handle: `@${name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-xl bg-white dark:bg-[#111b21] border border-[#e9edef] dark:border-[#222d34] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-[#111b21] dark:text-[#d1d7db] transition-colors">
        {/* Modal Top Header */}
        <div className="h-[60px] px-6 bg-[#f0f2f5] dark:bg-[#202c33] border-b border-[#e9edef] dark:border-[#222d34] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#00a884]/20 flex items-center justify-center text-[#00a884]">
              <Lock className="w-4 h-4" />
            </div>
            <h3 className="font-semibold text-[17px] text-[#111b21] dark:text-[#e9edef]">WhatsApp Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#54656f] dark:text-[#aebac1] hover:text-[#111b21] dark:hover:text-[#e9edef] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Horizontal Navigation Tabs */}
        <div className="flex items-center gap-1 px-4 py-2 bg-white dark:bg-[#111b21] border-b border-[#e9edef] dark:border-[#222d34] overflow-x-auto text-xs font-medium">
          {[
            { id: 'profile', label: 'Profile', icon: User },
            { id: 'chats', label: 'Chats & Theme', icon: Palette },
            { id: 'privacy', label: 'Privacy & Security', icon: ShieldCheck },
            { id: 'app', label: 'Install & Share', icon: Smartphone }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-full flex items-center gap-1.5 transition-colors shrink-0 ${
                  isActive
                    ? 'bg-[#00a884] text-white font-semibold'
                    : 'text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] hover:bg-[#f0f2f5] dark:hover:bg-[#202c33]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-[#111b21] dark:text-[#d1d7db]">
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="space-y-6">
              {/* Profile Card */}
              <div className="flex items-center gap-4 p-4 rounded-xl bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34]">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-16 h-16 rounded-full object-cover ring-2 ring-[#00a884]"
                />
                <div className="min-w-0 flex-1">
                  <h4 className="font-semibold text-lg text-[#111b21] dark:text-[#e9edef] truncate">{currentUser.name}</h4>
                  <p className="text-xs text-[#00a884] font-medium">{currentUser.handle} • Active Now</p>
                  <p className="text-xs text-[#667781] dark:text-[#8696a0] mt-1 italic truncate">"{about}"</p>
                </div>
              </div>

              {/* Persona Quick Switch */}
              <div className="p-4 rounded-xl bg-[#f0f2f5] dark:bg-[#182229] border border-[#e9edef] dark:border-[#222d34] space-y-2">
                <span className="text-xs font-medium text-[#667781] dark:text-[#8696a0] uppercase tracking-wider block">
                  Switch Active Persona
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => onSwitchUser('me')}
                    className={`p-2.5 rounded-lg border text-left flex items-center gap-2.5 transition-all ${
                      currentUser.id === 'me'
                        ? 'border-[#00a884] bg-[#d9fdd3] dark:bg-[#005c4b]/30 text-[#008069] dark:text-[#00a884]'
                        : 'border-[#e9edef] dark:border-[#222d34] bg-white dark:bg-[#202c33] hover:border-[#00a884] text-[#111b21] dark:text-[#d1d7db]'
                    }`}
                  >
                    <img
                      src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"
                      className="w-7 h-7 rounded-full object-cover"
                      alt="Rahotma"
                    />
                    <div>
                      <div className="text-xs font-semibold">Rahotma</div>
                      <div className="text-[10px] text-[#667781] dark:text-[#8696a0]">Main User</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => onSwitchUser('santo-rahman')}
                    className={`p-2.5 rounded-lg border text-left flex items-center gap-2.5 transition-all ${
                      currentUser.id === 'santo-rahman'
                        ? 'border-[#00a884] bg-[#d9fdd3] dark:bg-[#005c4b]/30 text-[#008069] dark:text-[#00a884]'
                        : 'border-[#e9edef] dark:border-[#222d34] bg-white dark:bg-[#202c33] hover:border-[#00a884] text-[#111b21] dark:text-[#d1d7db]'
                    }`}
                  >
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                      className="w-7 h-7 rounded-full object-cover"
                      alt="Santo"
                    />
                    <div>
                      <div className="text-xs font-semibold">Santo Rahman</div>
                      <div className="text-[10px] text-[#667781] dark:text-[#8696a0]">Co-Founder</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Edit Details */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-[#667781] dark:text-[#8696a0] mb-1.5">
                    Your Name (Visible to WhatsApp contacts)
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] focus:border-[#00a884] text-[#111b21] dark:text-[#e9edef] rounded-lg px-3.5 py-2.5 text-sm focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#667781] dark:text-[#8696a0] mb-1.5">
                    About / Status
                  </label>
                  <input
                    type="text"
                    value={about}
                    onChange={(e) => setAbout(e.target.value)}
                    className="w-full bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] focus:border-[#00a884] text-[#111b21] dark:text-[#e9edef] rounded-lg px-3.5 py-2.5 text-sm focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                {isSaved && <span className="text-xs text-[#00a884] font-medium">✓ Changes saved successfully</span>}
                <button
                  type="submit"
                  className="ml-auto px-5 py-2 bg-[#00a884] text-white hover:bg-[#02906f] font-semibold text-sm rounded-lg transition-all"
                >
                  Save Profile
                </button>
              </div>
            </form>
          )}

          {activeTab === 'chats' && (
            <div className="space-y-4">
              {/* Theme Selector */}
              <div className="p-4 rounded-xl bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">Theme &amp; Background</h5>
                    <p className="text-xs text-[#667781] dark:text-[#8696a0]">
                      Choose your preferred WhatsApp display mode
                    </p>
                  </div>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded bg-[#00a884]/15 text-[#00a884]">
                    {theme === 'light' ? 'Light (Default)' : 'Dark'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  {/* Light (White) option */}
                  <button
                    type="button"
                    onClick={() => {
                      if (theme !== 'light' && onToggleTheme) onToggleTheme();
                    }}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all ${
                      theme === 'light'
                        ? 'border-[#00a884] ring-2 ring-[#00a884]/30 bg-white'
                        : 'border-[#e9edef] dark:border-[#222d34] bg-white/50 dark:bg-[#182229] hover:border-[#00a884]'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                      <Sun className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-[#111b21] dark:text-white flex items-center gap-1">
                        <span>Light Theme</span>
                        {theme === 'light' && <span className="text-[10px] text-[#00a884]">✓</span>}
                      </div>
                      <div className="text-[10px] text-[#667781] dark:text-[#8696a0] mt-0.5">
                        Clean white background with light WhatsApp doodle wallpaper
                      </div>
                    </div>
                  </button>

                  {/* Dark option */}
                  <button
                    type="button"
                    onClick={() => {
                      if (theme !== 'dark' && onToggleTheme) onToggleTheme();
                    }}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all ${
                      theme === 'dark'
                        ? 'border-[#00a884] ring-2 ring-[#00a884]/30 bg-[#182229]'
                        : 'border-[#e9edef] dark:border-[#222d34] bg-white dark:bg-[#182229] hover:border-[#00a884]'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-cyan-400 flex items-center justify-center shrink-0">
                      <Moon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-[#111b21] dark:text-white flex items-center gap-1">
                        <span>Dark Theme</span>
                        {theme === 'dark' && <span className="text-[10px] text-[#00a884]">✓</span>}
                      </div>
                      <div className="text-[10px] text-[#667781] dark:text-[#8696a0] mt-0.5">
                        Classic WhatsApp dark mode (#0b141a)
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Chat Wallpaper info */}
              <div className="p-4 rounded-xl bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] space-y-2">
                <h5 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">Doodle Wallpaper Pattern</h5>
                <p className="text-xs text-[#667781] dark:text-[#8696a0]">
                  Authentic high-resolution WhatsApp doodles dynamically render across all chats for a natural chat experience.
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <div className="w-6 h-6 rounded-full bg-white border border-gray-300 shadow-2xs" />
                  <span className="text-xs text-[#111b21] dark:text-[#e9edef]">Default White Background (#ffffff)</span>
                </div>
              </div>

              {/* Contacts Management */}
              <div className="p-4 rounded-xl bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] space-y-3">
                <h5 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">Contacts Management</h5>
                <p className="text-xs text-[#667781] dark:text-[#8696a0]">
                  Quickly sync device contacts from your mobile phonebook or import a vCard file.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenSyncContacts();
                  }}
                  className="px-4 py-2 rounded-lg bg-[#00a884] text-white hover:bg-[#02906f] font-semibold text-xs flex items-center gap-2"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Sync Device Contacts</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-[#00a884] shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">End-to-End Encryption</h5>
                  <p className="text-xs text-[#667781] dark:text-[#8696a0] mt-1 leading-relaxed">
                    All text messages, media files, voice notes, and calls are encrypted with WebCrypto AES-256-GCM. Nobody in between, including network carriers, can decrypt them.
                  </p>
                </div>
              </div>

              <div className="divide-y divide-[#e9edef] dark:divide-[#222d34] bg-[#f0f2f5] dark:bg-[#202c33] rounded-xl border border-[#e9edef] dark:border-[#222d34]">
                <div className="p-3.5 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-[#111b21] dark:text-[#e9edef]">Last seen and online</div>
                    <div className="text-xs text-[#667781] dark:text-[#8696a0]">Everyone</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#667781] dark:text-[#8696a0]" />
                </div>
                <div className="p-3.5 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-[#111b21] dark:text-[#e9edef]">Read receipts</div>
                    <div className="text-xs text-[#667781] dark:text-[#8696a0]">If turned off, you won't send or receive read receipts</div>
                  </div>
                  <input type="checkbox" defaultChecked className="accent-[#00a884] w-4 h-4" />
                </div>
                <div className="p-3.5 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-[#111b21] dark:text-[#e9edef]">Default message timer</div>
                    <div className="text-xs text-[#667781] dark:text-[#8696a0]">Start new chats with disappearing messages</div>
                  </div>
                  <span className="text-xs text-[#00a884] font-medium">Off</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'app' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#00a884]/20 flex items-center justify-center text-[#00a884]">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">Install WhatsApp Applet</h5>
                    <p className="text-xs text-[#667781] dark:text-[#8696a0]">Add to Home Screen on your phone or install as desktop app</p>
                  </div>
                </div>

                <div className="p-3 bg-white dark:bg-[#111b21] rounded-xl flex items-center justify-between gap-2 border border-[#e9edef] dark:border-[#222d34]">
                  <span className="font-mono text-xs text-[#667781] dark:text-[#8696a0] truncate select-all">{appUrl}</span>
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 rounded-lg bg-[#00a884] text-white font-semibold text-xs flex items-center gap-1.5 hover:bg-[#02906f] shrink-0"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'Copied' : 'Copy Link'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenDownloadApp();
                    }}
                    className="flex-1 py-2 rounded-lg bg-[#e9edef] dark:bg-[#2a3942] hover:bg-[#dfe5e7] dark:hover:bg-[#374248] text-[#111b21] dark:text-[#e9edef] text-xs font-semibold flex items-center justify-center gap-2"
                  >
                    <Download className="w-3.5 h-3.5 text-[#00a884]" />
                    <span>Download App &amp; Source (.zip)</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
