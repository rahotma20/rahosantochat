import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  Search, 
  MoreVertical, 
  Trash2, 
  UserX, 
  ShieldCheck, 
  X,
  Sparkles,
  Info,
  Sun,
  Moon
} from 'lucide-react';
import { Contact } from '../types/chat';

interface ChatHeaderProps {
  contact: Contact;
  onBack: () => void;
  onOpenSafetyVerification: () => void;
  onStartCall: (type: 'audio' | 'video') => void;
  onToggleDrawer: () => void;
  searchInChat: string;
  onSearchInChatChange: (query: string) => void;
  isSearching: boolean;
  setIsSearching: (val: boolean) => void;
  onSimulateContactReply: () => void;
  onClearChat: () => void;
  onDeleteContact: () => void;
  theme?: 'light' | 'dark';
  onToggleTheme?: () => void;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({
  contact,
  onBack,
  onOpenSafetyVerification,
  onStartCall,
  onToggleDrawer,
  searchInChat,
  onSearchInChatChange,
  isSearching,
  setIsSearching,
  onSimulateContactReply,
  onClearChat,
  onDeleteContact,
  theme = 'light',
  onToggleTheme
}) => {
  const [showOptionsDropdown, setShowOptionsDropdown] = useState(false);

  return (
    <header className="h-[60px] px-4 bg-[#f0f2f5] dark:bg-[#202c33] border-b border-[#e9edef] dark:border-[#222d34] flex items-center justify-between shrink-0 relative select-none transition-colors">
      {/* Left: Back button (mobile) + Contact info */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onBack}
          className="md:hidden p-1 -ml-1 text-[#54656f] dark:text-[#aebac1] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full"
          title="Back to chats"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onToggleDrawer}
            className="relative shrink-0 focus:outline-none"
            title="View contact info"
          >
            <img
              src={contact.avatar}
              alt={contact.name}
              className="w-10 h-10 rounded-full object-cover ring-1 ring-[#e9edef] dark:ring-[#222d34]"
            />
            {contact.status === 'online' && (
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#25d366] rounded-full ring-2 ring-[#f0f2f5] dark:ring-[#202c33]" />
            )}
          </button>

          <div
            onClick={onToggleDrawer}
            className="min-w-0 cursor-pointer text-left"
          >
            <div className="font-normal text-[16px] text-[#111b21] dark:text-[#e9edef] truncate flex items-center gap-1.5 leading-tight">
              <span>{contact.name}</span>
              {contact.isVerified && (
                <ShieldCheck className="w-3.5 h-3.5 text-[#00a884] shrink-0" />
              )}
            </div>
            <div className="text-[12px] text-[#667781] dark:text-[#8696a0] truncate leading-tight mt-0.5">
              {contact.status === 'online'
                ? 'online'
                : contact.status === 'typing'
                ? 'typing...'
                : contact.lastSeen || 'last seen recently'}
            </div>
          </div>
        </div>
      </div>

      {/* Right: WhatsApp Actions */}
      <div className="flex items-center gap-1 text-[#54656f] dark:text-[#aebac1]">
        {/* Theme quick toggle */}
        {onToggleTheme && (
          <button
            onClick={onToggleTheme}
            title={theme === 'dark' ? 'Switch to Light Mode (Default White background)' : 'Switch to Dark Mode'}
            className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-[#54656f]" />}
          </button>
        )}

        {/* Quick simulate reply trigger */}
        <button
          onClick={onSimulateContactReply}
          title={`Simulate reply from ${contact.name}`}
          className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#00a884] rounded-full transition-colors"
        >
          <Sparkles className="w-5 h-5 text-[#00a884]" />
        </button>

        <button
          onClick={() => onStartCall('video')}
          title="Video call"
          className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors"
        >
          <Video className="w-5 h-5" />
        </button>

        <button
          onClick={() => onStartCall('audio')}
          title="Voice call"
          className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors"
        >
          <Phone className="w-5 h-5" />
        </button>

        <button
          onClick={() => {
            setIsSearching(!isSearching);
            if (isSearching) onSearchInChatChange('');
          }}
          title="Search..."
          className={`p-2 rounded-full transition-colors ${
            isSearching ? 'bg-[#e9edef] dark:bg-[#374248] text-[#00a884]' : 'hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef]'
          }`}
        >
          <Search className="w-5 h-5" />
        </button>

        {/* 3-Dots More Options Menu */}
        <div className="relative">
          <button
            onClick={() => setShowOptionsDropdown(!showOptionsDropdown)}
            title="More options"
            className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {showOptionsDropdown && (
            <div className="absolute right-0 top-full mt-2 w-56 bg-white dark:bg-[#233138] border border-[#e9edef] dark:border-[#222d34] rounded-xl shadow-2xl py-2 z-50 text-sm text-[#111b21] dark:text-[#d1d7db] animate-in fade-in zoom-in-95 duration-100">
              <button
                onClick={() => {
                  setShowOptionsDropdown(false);
                  onToggleDrawer();
                }}
                className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
              >
                <Info className="w-4 h-4 text-[#667781] dark:text-[#aebac1]" />
                <span>Contact info</span>
              </button>

              <button
                onClick={() => {
                  setShowOptionsDropdown(false);
                  onOpenSafetyVerification();
                }}
                className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
              >
                <ShieldCheck className="w-4 h-4 text-[#00a884]" />
                <span>Verify security code</span>
              </button>

              <button
                onClick={() => {
                  setShowOptionsDropdown(false);
                  setIsSearching(true);
                }}
                className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
              >
                <Search className="w-4 h-4 text-[#667781] dark:text-[#aebac1]" />
                <span>Search in chat</span>
              </button>

              {onToggleTheme && (
                <button
                  onClick={() => {
                    setShowOptionsDropdown(false);
                    onToggleTheme();
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
                >
                  {theme === 'dark' ? (
                    <>
                      <Sun className="w-4 h-4 text-amber-500" />
                      <span>Switch to Light Theme (White)</span>
                    </>
                  ) : (
                    <>
                      <Moon className="w-4 h-4 text-[#54656f]" />
                      <span>Switch to Dark Theme</span>
                    </>
                  )}
                </button>
              )}

              <div className="my-1 border-t border-[#e9edef] dark:border-[#2a3942]" />

              <button
                onClick={() => {
                  setShowOptionsDropdown(false);
                  onClearChat();
                }}
                className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] text-amber-600 dark:text-amber-400 transition-colors flex items-center gap-3"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear chat</span>
              </button>

              <button
                onClick={() => {
                  setShowOptionsDropdown(false);
                  onDeleteContact();
                }}
                className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] text-rose-600 dark:text-rose-400 transition-colors flex items-center gap-3 font-medium"
              >
                <UserX className="w-4 h-4" />
                <span>Delete chat</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* In-chat search bar overlay */}
      {isSearching && (
        <div className="absolute inset-x-0 bottom-0 top-0 bg-[#f0f2f5] dark:bg-[#202c33] z-20 px-4 flex items-center gap-3">
          <Search className="w-4 h-4 text-[#667781] dark:text-[#8696a0]" />
          <input
            type="text"
            autoFocus
            value={searchInChat}
            onChange={(e) => onSearchInChatChange(e.target.value)}
            placeholder="Search messages..."
            className="flex-1 bg-transparent text-sm text-[#111b21] dark:text-[#e9edef] placeholder-[#667781] dark:placeholder-[#8696a0] focus:outline-none"
          />
          <button
            onClick={() => {
              setIsSearching(false);
              onSearchInChatChange('');
            }}
            className="p-1 text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      )}
    </header>
  );
};
