import React, { useState, useRef, useEffect } from 'react';
import { 
  Paperclip, 
  Send, 
  Mic, 
  Smile, 
  X, 
  Image as ImageIcon, 
  FileText, 
  Camera, 
  Trash2,
  Plus,
  Headphones
} from 'lucide-react';
import { MediaAttachment, MessageReplyInfo } from '../types/chat';
import { formatBytes } from '../utils/crypto';

interface MessageInputProps {
  onSendMessage: (text: string, mediaFiles?: MediaAttachment[]) => void;
  replyingTo: MessageReplyInfo | null;
  onCancelReply: () => void;
  onOpenLiveCamera: () => void;
}

const QUICK_EMOJIS = ['👍', '❤️', '😊', '😂', '🔥', '🙏', '🔒', '👏', '🤝', '⚡', '🎉', '💡', '✨', '👌'];

export const MessageInput: React.FC<MessageInputProps> = ({
  onSendMessage,
  replyingTo,
  onCancelReply,
  onOpenLiveCamera
}) => {
  const [text, setText] = useState('');
  const [pendingAttachments, setPendingAttachments] = useState<MediaAttachment[]>([]);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const timerIntervalRef = useRef<any>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [text]);

  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, []);

  const handleSend = () => {
    if (!text.trim() && pendingAttachments.length === 0) return;
    onSendMessage(text.trim(), pendingAttachments.length > 0 ? pendingAttachments : undefined);
    setText('');
    setPendingAttachments([]);
    setShowEmojiPicker(false);
    setShowAttachMenu(false);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      const isImg = file.type.startsWith('image/');
      const isVid = file.type.startsWith('video/');
      const isAud = file.type.startsWith('audio/');

      reader.onload = (event) => {
        const resultUrl = event.target?.result as string;
        const newAttachment: MediaAttachment = {
          id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          type: isImg ? 'image' : isVid ? 'video' : isAud ? 'audio' : 'document',
          url: resultUrl,
          name: file.name,
          size: file.size,
          mimeType: file.type
        };
        setPendingAttachments((prev) => [...prev, newAttachment]);
      };
      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setShowAttachMenu(false);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        const voiceAttachment: MediaAttachment = {
          id: `voice-${Date.now()}`,
          type: 'audio',
          url: audioUrl,
          name: `VoiceNote_${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.webm`,
          size: audioBlob.size,
          duration: recordingSeconds,
          mimeType: 'audio/webm'
        };
        onSendMessage('', [voiceAttachment]);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch {
      setIsRecording(true);
      setRecordingSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    }
  };

  const stopAndSendRecording = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    } else {
      const voiceAttachment: MediaAttachment = {
        id: `voice-${Date.now()}`,
        type: 'audio',
        url: 'https://assets.mixkit.co/active_storage/sfx/2874/2874-preview.mp3',
        name: `VoiceMessage_${Date.now().toString().slice(-4)}.mp3`,
        size: 320000,
        duration: Math.max(recordingSeconds, 3),
        mimeType: 'audio/mpeg'
      };
      onSendMessage('', [voiceAttachment]);
    }

    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const cancelRecording = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stream.getTracks().forEach((t) => t.stop());
    }
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const removeAttachment = (id: string) => {
    setPendingAttachments((prev) => prev.filter((att) => att.id !== id));
  };

  return (
    <div className="bg-[#f0f2f5] dark:bg-[#202c33] border-t border-[#e9edef] dark:border-[#222d34] px-4 py-2 shrink-0 select-none transition-colors">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        multiple
        className="hidden"
      />

      {/* WhatsApp Replying Preview Card */}
      {replyingTo && (
        <div className="flex items-center justify-between p-2 mb-2 bg-white dark:bg-[#182229] rounded-lg border-l-4 border-[#00a884] text-xs shadow-2xs animate-in fade-in duration-100">
          <div className="min-w-0 pr-2">
            <span className="font-semibold text-[#00a884] block truncate">
              {replyingTo.senderName}
            </span>
            <span className="text-[#667781] dark:text-[#8696a0] truncate block">
              {replyingTo.text || (replyingTo.mediaType ? `[${replyingTo.mediaType.toUpperCase()}]` : '')}
            </span>
          </div>
          <button
            onClick={onCancelReply}
            className="p-1 text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* WhatsApp Pending Attachments Preview Bar */}
      {pendingAttachments.length > 0 && (
        <div className="flex items-center gap-2 p-2 mb-2 overflow-x-auto bg-white dark:bg-[#182229] rounded-xl border border-[#e9edef] dark:border-[#222d34]">
          {pendingAttachments.map((att) => (
            <div
              key={att.id}
              className="relative shrink-0 w-20 h-20 rounded-lg overflow-hidden border border-[#e9edef] dark:border-[#222d34] bg-[#f0f2f5] dark:bg-[#111b21] group"
            >
              {att.type === 'image' ? (
                <img src={att.url} alt={att.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-1 text-center">
                  <FileText className="w-6 h-6 text-[#00a884] mb-0.5" />
                  <span className="text-[9px] text-[#667781] dark:text-[#8696a0] truncate w-full px-1">{att.name}</span>
                </div>
              )}
              <button
                onClick={() => removeAttachment(att.id)}
                className="absolute top-1 right-1 p-0.5 bg-black/80 hover:bg-rose-600 text-white rounded-full transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
              <div className="absolute bottom-0 inset-x-0 bg-black/70 text-[8px] text-center text-white py-0.5">
                {formatBytes(att.size)}
              </div>
            </div>
          ))}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="shrink-0 w-20 h-20 rounded-lg border-2 border-dashed border-[#cccccc] dark:border-[#374248] hover:border-[#00a884] flex flex-col items-center justify-center text-[#667781] dark:text-[#8696a0] hover:text-[#00a884] transition-colors"
          >
            <Plus className="w-5 h-5 mb-1" />
            <span className="text-[10px]">Add more</span>
          </button>
        </div>
      )}

      {/* WhatsApp Voice Recording Active Bar */}
      {isRecording ? (
        <div className="flex items-center justify-between py-1.5 px-3 bg-white dark:bg-[#182229] border border-[#00a884]/40 rounded-full animate-pulse shadow-xs">
          <div className="flex items-center gap-2.5">
            <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
            <span className="text-xs font-semibold text-[#111b21] dark:text-[#e9edef]">
              {Math.floor(recordingSeconds / 60)}:{(recordingSeconds % 60).toString().padStart(2, '0')}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={cancelRecording}
              className="p-1.5 text-[#667781] dark:text-[#8696a0] hover:text-rose-500 rounded-full transition-colors"
              title="Cancel recording"
            >
              <Trash2 className="w-5 h-5" />
            </button>
            <button
              onClick={stopAndSendRecording}
              className="p-2 bg-[#00a884] hover:bg-[#02906f] text-white rounded-full transition-colors shadow-md"
              title="Send voice note"
            >
              <Send className="w-4 h-4 fill-current ml-0.5" />
            </button>
          </div>
        </div>
      ) : (
        /* WhatsApp Input Controls */
        <div className="flex items-center gap-2 relative">
          {/* Smiley Emoji Icon on Left */}
          <div className="relative">
            <button
              onClick={() => {
                setShowEmojiPicker(!showEmojiPicker);
                setShowAttachMenu(false);
              }}
              title="Emoji"
              className={`p-2 text-[#54656f] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors ${
                showEmojiPicker ? 'text-[#00a884]' : ''
              }`}
            >
              <Smile className="w-6 h-6" />
            </button>

            {/* Quick Emoji Popover */}
            {showEmojiPicker && (
              <div className="absolute bottom-full left-0 mb-3 w-64 bg-white dark:bg-[#233138] border border-[#e9edef] dark:border-[#222d34] rounded-2xl shadow-2xl p-3 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="text-[11px] font-semibold text-[#667781] dark:text-[#8696a0] mb-2 uppercase tracking-wider">
                  WhatsApp Emojis
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {QUICK_EMOJIS.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => {
                        setText((prev) => prev + emoji);
                        setShowEmojiPicker(false);
                      }}
                      className="p-1.5 text-lg hover:bg-[#f0f2f5] dark:hover:bg-[#182229] rounded-md transition-transform hover:scale-125"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Plus / Attachment Icon */}
          <div className="relative">
            <button
              onClick={() => {
                setShowAttachMenu(!showAttachMenu);
                setShowEmojiPicker(false);
              }}
              title="Attach"
              className={`p-2 text-[#54656f] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors ${
                showAttachMenu ? 'text-[#00a884] rotate-45' : ''
              }`}
            >
              <Plus className="w-6 h-6 transition-transform" />
            </button>

            {/* WhatsApp Attachment Popup with colorful circle icons */}
            {showAttachMenu && (
              <div className="absolute bottom-full left-0 mb-3 w-52 bg-white dark:bg-[#233138] border border-[#e9edef] dark:border-[#222d34] rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-100 space-y-1">
                <button
                  onClick={() => {
                    if (fileInputRef.current) {
                      fileInputRef.current.accept = 'image/*,video/*';
                      fileInputRef.current.click();
                    }
                  }}
                  className="w-full p-2 flex items-center gap-3 text-xs text-[#111b21] dark:text-[#e9edef] hover:bg-[#f5f6f6] dark:hover:bg-[#182229] rounded-xl transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#bf59cf] to-[#c862d8] text-white flex items-center justify-center shrink-0 shadow-md">
                    <ImageIcon className="w-4 h-4" />
                  </div>
                  <span>Photos &amp; videos</span>
                </button>

                <button
                  onClick={() => {
                    setShowAttachMenu(false);
                    onOpenLiveCamera();
                  }}
                  className="w-full p-2 flex items-center gap-3 text-xs text-[#111b21] dark:text-[#e9edef] hover:bg-[#f5f6f6] dark:hover:bg-[#182229] rounded-xl transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#ec407a] to-[#f06292] text-white flex items-center justify-center shrink-0 shadow-md">
                    <Camera className="w-4 h-4" />
                  </div>
                  <span>Camera</span>
                </button>

                <button
                  onClick={() => {
                    if (fileInputRef.current) {
                      fileInputRef.current.accept = '.pdf,.doc,.docx,.txt,.zip,.xls,.xlsx';
                      fileInputRef.current.click();
                    }
                  }}
                  className="w-full p-2 flex items-center gap-3 text-xs text-[#111b21] dark:text-[#e9edef] hover:bg-[#f5f6f6] dark:hover:bg-[#182229] rounded-xl transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#5f66cd] to-[#7986cb] text-white flex items-center justify-center shrink-0 shadow-md">
                    <FileText className="w-4 h-4" />
                  </div>
                  <span>Document</span>
                </button>

                <button
                  onClick={() => {
                    if (fileInputRef.current) {
                      fileInputRef.current.accept = 'audio/*';
                      fileInputRef.current.click();
                    }
                  }}
                  className="w-full p-2 flex items-center gap-3 text-xs text-[#111b21] dark:text-[#e9edef] hover:bg-[#f5f6f6] dark:hover:bg-[#182229] rounded-xl transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#ff9800] to-[#ffb74d] text-white flex items-center justify-center shrink-0 shadow-md">
                    <Headphones className="w-4 h-4" />
                  </div>
                  <span>Audio</span>
                </button>
              </div>
            )}
          </div>

          {/* WhatsApp Text Input Box */}
          <div className="flex-1 bg-white dark:bg-[#2a3942] rounded-lg px-4 py-2 min-h-[42px] max-h-32 flex items-center border border-[#e9edef] dark:border-transparent focus-within:border-[#00a884] shadow-2xs transition-colors">
            <textarea
              ref={textareaRef}
              rows={1}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message"
              className="w-full bg-transparent text-[15px] text-[#111b21] dark:text-[#d1d7db] placeholder-[#667781] dark:placeholder-[#8696a0] resize-none focus:outline-none max-h-28 overflow-y-auto leading-[20px]"
            />
          </div>

          {/* WhatsApp Mic or Send Button on Right */}
          {text.trim() || pendingAttachments.length > 0 ? (
            <button
              onClick={handleSend}
              title="Send message"
              className="p-2 text-[#00a884] hover:text-[#02906f] transition-transform active:scale-95 shrink-0"
            >
              <Send className="w-6 h-6 fill-current" />
            </button>
          ) : (
            <button
              onClick={startRecording}
              title="Voice message"
              className="p-2 text-[#54656f] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] transition-colors shrink-0"
            >
              <Mic className="w-6 h-6" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
