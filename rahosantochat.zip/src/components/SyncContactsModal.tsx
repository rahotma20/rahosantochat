import React, { useState, useRef } from 'react';
import { 
  X, 
  RefreshCw, 
  Smartphone, 
  Upload, 
  FileText, 
  Check, 
  UserPlus, 
  Users, 
  AlertCircle, 
  Sparkles,
  ClipboardList
} from 'lucide-react';
import { Contact } from '../types/chat';
import { formatSafetyNumber } from '../utils/crypto';

interface SyncContactsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportContacts: (contacts: Contact[]) => void;
}

const AVATAR_PALETTES = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80'
];

export const SyncContactsModal: React.FC<SyncContactsModalProps> = ({
  isOpen,
  onClose,
  onImportContacts
}) => {
  const [activeTab, setActiveTab] = useState<'device' | 'file' | 'paste'>('device');
  const [parsedContacts, setParsedContacts] = useState<Contact[]>([]);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [pasteText, setPasteText] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const isNativeContactPickerSupported =
    typeof navigator !== 'undefined' && 'contacts' in navigator && 'ContactsManager' in window;

  const createContactObject = (name: string, phone: string, email?: string): Contact => {
    const contactId = `contact-sync-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    const randomAvatar = AVATAR_PALETTES[Math.floor(Math.random() * AVATAR_PALETTES.length)];
    const cleanPhone = phone || '+62 812-0000-0000';
    const cleanName = name.trim() || 'New Contact';
    const safetyNumber = formatSafetyNumber(contactId + cleanPhone).join(' ');

    return {
      id: contactId,
      name: cleanName,
      handle: `@${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
      phone: cleanPhone,
      email: email || `${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '.')}@contact.net`,
      role: 'Contact Person',
      avatar: randomAvatar,
      avatarColor: 'from-emerald-500 to-teal-700',
      status: 'online',
      lastSeen: 'Synced Contact',
      safetyNumber,
      isVerified: true,
      isPinned: false,
      isMuted: false,
      isBlocked: false,
      disappearingTimer: 0,
      customPublicKeyFingerprint: `SHA256:${Array.from({ length: 8 }, () =>
        Math.floor(Math.random() * 256)
          .toString(16)
          .padStart(2, '0')
          .toUpperCase()
      ).join(':')}`
    };
  };

  // 1. Sync directly from device phonebook using Web Contacts API
  const handleNativeDeviceSync = async () => {
    setErrorMessage(null);
    setStatusMessage(null);

    try {
      if (isNativeContactPickerSupported) {
        const props = ['name', 'tel', 'email'];
        const opts = { multiple: true };
        const contacts = await (navigator as any).contacts.select(props, opts);

        if (contacts && contacts.length > 0) {
          const formatted: Contact[] = contacts.map((c: any) => {
            const name = Array.isArray(c.name) ? c.name[0] : c.name || 'Mobile Contact';
            const phone = Array.isArray(c.tel) ? c.tel[0] : c.tel || '';
            const email = Array.isArray(c.email) ? c.email[0] : c.email || '';
            return createContactObject(name, phone, email);
          });
          setParsedContacts(formatted);
          setStatusMessage(`Found ${formatted.length} contact(s) from your device!`);
        }
      } else {
        // Guide user or provide mock phone contacts for testing
        setErrorMessage(
          'Direct browser address book access requires Android Chrome or a mobile device. You can import your .vcf or Google Contacts CSV file below.'
        );
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setErrorMessage('Failed to access phone contacts: ' + (err.message || 'Permission denied'));
      }
    }
  };

  // 2. Parse vCard (.vcf) or CSV file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMessage(null);
    setStatusMessage(null);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (!content) return;

      if (file.name.endsWith('.vcf') || content.includes('BEGIN:VCARD')) {
        parseVCF(content);
      } else if (file.name.endsWith('.csv') || content.includes(',')) {
        parseCSV(content);
      } else {
        setErrorMessage('Unsupported file format. Please upload a .vcf or .csv file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const parseVCF = (content: string) => {
    const vcards = content.split(/BEGIN:VCARD/i).filter((block) => block.trim().length > 0);
    const results: Contact[] = [];

    vcards.forEach((card) => {
      let name = '';
      let phone = '';
      let email = '';

      const lines = card.split(/\r\n|\r|\n/);
      for (const line of lines) {
        if (line.startsWith('FN:') || line.startsWith('FN;')) {
          name = line.replace(/^FN[^:]*:/i, '').trim();
        } else if (!name && (line.startsWith('N:') || line.startsWith('N;'))) {
          const parts = line.replace(/^N[^:]*:/i, '').split(';');
          name = `${parts[1] || ''} ${parts[0] || ''}`.trim();
        } else if (!phone && line.includes('TEL')) {
          phone = line.replace(/^TEL[^:]*:/i, '').trim();
        } else if (!email && line.includes('EMAIL')) {
          email = line.replace(/^EMAIL[^:]*:/i, '').trim();
        }
      }

      if (name || phone) {
        results.push(createContactObject(name || phone, phone, email));
      }
    });

    if (results.length > 0) {
      setParsedContacts(results);
      setStatusMessage(`Successfully parsed ${results.length} contacts from vCard file.`);
    } else {
      setErrorMessage('No valid contacts could be read from this vCard file.');
    }
  };

  const parseCSV = (content: string) => {
    const lines = content.split(/\r\n|\r|\n/).filter((l) => l.trim().length > 0);
    if (lines.length < 2) {
      setErrorMessage('CSV file appears empty or missing rows.');
      return;
    }

    const headers = lines[0].toLowerCase().split(/,|;/).map((h) => h.trim().replace(/"/g, ''));
    let nameIdx = headers.findIndex((h) => h.includes('name') || h.includes('first'));
    let phoneIdx = headers.findIndex((h) => h.includes('phone') || h.includes('tel') || h.includes('mobile'));
    let emailIdx = headers.findIndex((h) => h.includes('email') || h.includes('mail'));

    if (nameIdx === -1) nameIdx = 0;
    if (phoneIdx === -1) phoneIdx = 1;

    const results: Contact[] = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(/,|;/).map((c) => c.trim().replace(/"/g, ''));
      const name = cols[nameIdx];
      const phone = cols[phoneIdx] || '';
      const email = emailIdx !== -1 ? cols[emailIdx] : '';

      if (name && name.length > 1) {
        results.push(createContactObject(name, phone, email));
      }
    }

    if (results.length > 0) {
      setParsedContacts(results);
      setStatusMessage(`Successfully parsed ${results.length} contacts from CSV.`);
    } else {
      setErrorMessage('Could not extract contacts from CSV.');
    }
  };

  // 3. Parse pasted text lines
  const handleParsePastedText = () => {
    if (!pasteText.trim()) return;
    const lines = pasteText.split(/\r\n|\r|\n/).filter((l) => l.trim().length > 0);
    const results: Contact[] = [];

    lines.forEach((line) => {
      // Split by comma, dash, or tab
      const parts = line.split(/[,;\-\t]/).map((p) => p.trim());
      if (parts[0]) {
        const name = parts[0];
        const phone = parts[1] || '';
        const email = parts[2] || '';
        results.push(createContactObject(name, phone, email));
      }
    });

    if (results.length > 0) {
      setParsedContacts(results);
      setStatusMessage(`Parsed ${results.length} contacts from text input.`);
    }
  };

  const handleConfirmImport = () => {
    if (parsedContacts.length === 0) return;
    onImportContacts(parsedContacts);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150 select-none">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-[#e9edef] dark:border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-[#111b21] dark:text-slate-100 transition-colors">
        {/* Header */}
        <div className="p-4 border-b border-[#e9edef] dark:border-slate-800 flex items-center justify-between bg-[#f0f2f5] dark:bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 p-0.5 shadow-md">
              <div className="w-full h-full bg-[#f0f2f5] dark:bg-slate-950 rounded-[10px] flex items-center justify-center">
                <RefreshCw className="w-4.5 h-4.5 text-[#00a884]" />
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-sm text-[#111b21] dark:text-slate-100">Sync Original Contacts</h3>
              <p className="text-xs text-[#667781] dark:text-slate-400">Import your real phone contacts or vCard/CSV</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#667781] dark:text-slate-400 hover:text-[#111b21] dark:hover:text-white hover:bg-gray-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="px-5 pt-4">
          <div className="flex items-center gap-1 p-1 bg-[#f0f2f5] dark:bg-slate-950 rounded-xl border border-[#e9edef] dark:border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('device')}
              className={`flex-1 py-1.5 rounded-lg font-medium transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'device'
                  ? 'bg-emerald-600 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>Mobile Phonebook</span>
            </button>

            <button
              onClick={() => setActiveTab('file')}
              className={`flex-1 py-1.5 rounded-lg font-medium transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'file'
                  ? 'bg-emerald-600 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Upload className="w-4 h-4" />
              <span>Import .VCF / CSV</span>
            </button>

            <button
              onClick={() => setActiveTab('paste')}
              className={`flex-1 py-1.5 rounded-lg font-medium transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'paste'
                  ? 'bg-emerald-600 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ClipboardList className="w-4 h-4" />
              <span>Paste List</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Tab 1: Device Native Sync */}
          {activeTab === 'device' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl shrink-0">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white">Direct Phonebook Sync</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      Tap below to select contacts directly from your phone's address book (Google Contacts, iCloud, or SIM).
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleNativeDeviceSync}
                  className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Sync Contacts from Device</span>
                </button>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-400 space-y-1">
                <p className="font-semibold text-slate-300">How to export from your phone if on Desktop:</p>
                <p className="text-[11px] leading-relaxed">
                  • <strong>Android</strong>: Open Contacts app &gt; Settings &gt; Export to .vcf file, then upload it under the <strong>Import .VCF</strong> tab.<br />
                  • <strong>iPhone</strong>: Go to Contacts app &gt; Select Lists &gt; Export &gt; Export vCard.<br />
                  • <strong>Google Contacts</strong>: Visit contacts.google.com &gt; Export &gt; vCard or Google CSV.
                </p>
              </div>
            </div>
          )}

          {/* Tab 2: File Upload */}
          {activeTab === 'file' && (
            <div className="space-y-4">
              <input
                ref={fileInputRef}
                type="file"
                accept=".vcf,.csv,text/vcard,text/csv"
                onChange={handleFileUpload}
                className="hidden"
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-8 border-2 border-dashed border-slate-700 hover:border-emerald-500/50 bg-slate-950/60 hover:bg-slate-950 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-all group"
              >
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-sm text-white">Click to Upload Contacts File</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Supports <strong>.vcf</strong> (vCard) and <strong>.csv</strong> (Google Contacts, Outlook)
                </p>
                <span className="mt-3 text-[11px] text-emerald-400 font-semibold px-3 py-1 bg-emerald-950/40 border border-emerald-500/30 rounded-lg">
                  Browse Files
                </span>
              </div>
            </div>
          )}

          {/* Tab 3: Paste Contacts */}
          {activeTab === 'paste' && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Paste contacts list (One contact per line: Name, Phone)
                </label>
                <textarea
                  rows={4}
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  placeholder="John Doe, +62 812-3456-7890&#10;Alice Smith, +62 813-9999-8888&#10;Robert Tan, +62 811-2222-3333"
                  className="w-full bg-slate-800 text-xs font-mono text-slate-200 placeholder-slate-500 p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                onClick={handleParsePastedText}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors border border-slate-700"
              >
                Parse Contacts
              </button>
            </div>
          )}

          {/* Alerts / Feedback */}
          {errorMessage && (
            <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {statusMessage && (
            <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* Parsed Contacts Preview List */}
          {parsedContacts.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200">
                  Ready to Sync ({parsedContacts.length})
                </span>
                <button
                  onClick={() => setParsedContacts([])}
                  className="text-slate-400 hover:text-slate-200"
                >
                  Clear
                </button>
              </div>

              <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                {parsedContacts.map((c) => (
                  <div
                    key={c.id}
                    className="p-2.5 bg-slate-950/80 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs"
                  >
                    <div className="min-w-0">
                      <p className="font-semibold text-slate-200 truncate">{c.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">{c.phone || c.email}</p>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono">E2EE Key Generated</span>
                  </div>
                ))}
              </div>

              <button
                onClick={handleConfirmImport}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 mt-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>Add {parsedContacts.length} Contact(s) to Rahosantochat</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
