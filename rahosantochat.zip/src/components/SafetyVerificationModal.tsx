import React from 'react';
import { X, ShieldCheck, Check, QrCode, Lock, Copy } from 'lucide-react';
import { Contact } from '../types/chat';
import { formatSafetyNumber } from '../utils/crypto';

interface SafetyVerificationModalProps {
  contact: Contact | null;
  isOpen: boolean;
  onClose: () => void;
  onToggleVerify: (contactId: string) => void;
}

export const SafetyVerificationModal: React.FC<SafetyVerificationModalProps> = ({
  contact,
  isOpen,
  onClose,
  onToggleVerify
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !contact) return null;

  const blocks = formatSafetyNumber(contact.id + contact.phone);

  const handleCopy = () => {
    navigator.clipboard.writeText(blocks.join(' '));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150 select-none">
      <div className="w-full max-w-md bg-[#111b21] border border-[#222d34] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-[#222d34] flex items-center justify-between bg-[#202c33]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#00a884]/20 text-[#00a884] rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-[#e9edef]">Verify Security Code</h3>
              <p className="text-xs text-[#8696a0]">{contact.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#8696a0] hover:text-[#e9edef] hover:bg-[#374248]/50 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-center">
          {/* QR Code representation */}
          <div className="flex flex-col items-center">
            <div className="w-40 h-40 bg-white p-3 rounded-2xl shadow-lg flex items-center justify-center">
              {/* SVG QR Code Simulation */}
              <svg viewBox="0 0 100 100" className="w-full h-full fill-slate-900">
                <rect x="5" y="5" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="6" />
                <rect x="13" y="13" width="12" height="12" />
                
                <rect x="67" y="5" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="6" />
                <rect x="75" y="13" width="12" height="12" />
                
                <rect x="5" y="67" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="6" />
                <rect x="13" y="75" width="12" height="12" />
                
                {/* Random QR data points */}
                <rect x="42" y="12" width="6" height="6" />
                <rect x="52" y="18" width="6" height="6" />
                <rect x="42" y="32" width="6" height="6" />
                <rect x="12" y="42" width="6" height="6" />
                <rect x="22" y="52" width="6" height="6" />
                <rect x="48" y="48" width="10" height="10" />
                <rect x="68" y="42" width="6" height="6" />
                <rect x="78" y="52" width="6" height="6" />
                <rect x="42" y="68" width="6" height="6" />
                <rect x="54" y="78" width="6" height="6" />
                <rect x="72" y="72" width="6" height="6" />
                <rect x="84" y="84" width="6" height="6" />
              </svg>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              Scan with your contact’s phone camera to verify instant match
            </p>
          </div>

          {/* 60-digit safety blocks (12 blocks of 5) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-[#8696a0]">Security Code</span>
              <button
                onClick={handleCopy}
                className="text-xs font-medium text-[#00a884] hover:text-[#00c59b] flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 bg-[#0c1317] p-3 rounded-xl border border-[#222d34] text-center font-mono text-xs text-[#00a884] tracking-wider">
              {blocks.map((block, i) => (
                <div key={i} className="py-1 bg-[#202c33] rounded border border-[#2a3942]">
                  {block}
                </div>
              ))}
            </div>
          </div>

          {/* SHA-256 Fingerprint */}
          <div className="text-left bg-[#0c1317] p-3 rounded-xl border border-[#222d34] text-xs">
            <div className="text-[#8696a0] text-[11px] font-medium mb-1">Public Key Fingerprint</div>
            <code className="text-[#d1d7db] font-mono text-[10px] break-all block">
              {contact.customPublicKeyFingerprint}
            </code>
          </div>

          {/* Verification Explanation */}
          <p className="text-xs text-[#8696a0] text-left leading-relaxed">
            All messages and media shared between you and <strong>{contact.name}</strong> are protected with end-to-end encryption. Compare this number with your contact’s device to verify that messages and calls are encrypted.
          </p>

          {/* Verification Status Button */}
          <button
            onClick={() => onToggleVerify(contact.id)}
            className={`w-full py-2.5 px-4 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-all ${
              contact.isVerified
                ? 'bg-[#00a884]/20 text-[#00a884] border border-[#00a884]/40 hover:bg-[#00a884]/30'
                : 'bg-[#00a884] hover:bg-[#02906f] text-[#111b21]'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{contact.isVerified ? 'Mark as Unverified' : 'Mark as Verified'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
