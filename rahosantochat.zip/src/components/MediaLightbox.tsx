import React, { useState } from 'react';
import { X, Download, ZoomIn, ZoomOut, RotateCw } from 'lucide-react';
import { MediaAttachment } from '../types/chat';
import { formatBytes } from '../utils/crypto';

interface MediaLightboxProps {
  media: MediaAttachment | null;
  onClose: () => void;
}

export const MediaLightbox: React.FC<MediaLightboxProps> = ({ media, onClose }) => {
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);

  if (!media) return null;

  const handleZoomIn = () => setScale((s) => Math.min(s + 0.25, 3));
  const handleZoomOut = () => setScale((s) => Math.max(s - 0.25, 0.5));
  const handleRotate = () => setRotation((r) => (r + 90) % 360);

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col justify-between animate-in fade-in duration-200">
      {/* Lightbox Topbar */}
      <div className="p-4 flex items-center justify-between border-b border-slate-800 bg-slate-950/60">
        <div className="text-left">
          <p className="text-sm font-semibold text-slate-100">{media.name}</p>
          <p className="text-xs text-slate-400">
            {formatBytes(media.size)} · {media.mimeType || media.type.toUpperCase()}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {media.type === 'image' && (
            <>
              <button
                onClick={handleZoomIn}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Zoom In"
              >
                <ZoomIn className="w-5 h-5" />
              </button>
              <button
                onClick={handleZoomOut}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Zoom Out"
              >
                <ZoomOut className="w-5 h-5" />
              </button>
              <button
                onClick={handleRotate}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Rotate 90deg"
              >
                <RotateCw className="w-5 h-5" />
              </button>
            </>
          )}

          <a
            href={media.url}
            download={media.name}
            className="p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition-colors"
            title="Download file"
          >
            <Download className="w-5 h-5" />
          </a>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="Close viewer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex items-center justify-center p-4 overflow-hidden">
        {media.type === 'image' ? (
          <img
            src={media.url}
            alt={media.name}
            style={{
              transform: `scale(${scale}) rotate(${rotation}deg)`,
              transition: 'transform 0.2s ease-out'
            }}
            className="max-h-[80vh] max-w-[90vw] object-contain rounded-lg shadow-2xl"
          />
        ) : media.type === 'video' ? (
          <video
            src={media.url}
            controls
            autoPlay
            className="max-h-[80vh] max-w-[90vw] rounded-lg shadow-2xl"
          />
        ) : (
          <div className="p-8 bg-slate-900 border border-slate-700 rounded-2xl text-center max-w-md">
            <p className="text-sm text-slate-300 mb-4">Preview not available for this file type.</p>
            <a
              href={media.url}
              download={media.name}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold rounded-lg"
            >
              <Download className="w-4 h-4" />
              <span>Download {media.name}</span>
            </a>
          </div>
        )}
      </div>

      {/* Lightbox Footer Note */}
      <div className="p-3 text-center text-xs text-slate-500 bg-slate-950/40 border-t border-slate-800/60">
        Decrypted in memory via Rahosantochat Zero-Knowledge Engine
      </div>
    </div>
  );
};
