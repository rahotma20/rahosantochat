import React, { useState, useEffect } from 'react';
import { 
  X, 
  Download, 
  Smartphone, 
  Monitor, 
  Check, 
  HardDrive, 
  Terminal, 
  ShieldCheck, 
  Share, 
  Copy, 
  QrCode, 
  ExternalLink,
  PlusSquare,
  AlertTriangle,
  Globe,
  Info
} from 'lucide-react';
import { downloadProjectZip } from '../utils/projectDownloader';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({ isOpen, onClose }) => {
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [activeTab, setActiveTab] = useState<'mobile' | 'desktop' | 'source'>('mobile');
  const [copiedDevLink, setCopiedDevLink] = useState(false);
  const [copiedPreLink, setCopiedPreLink] = useState(false);

  const devUrl = 'https://ais-dev-w7nmsuf6m34trgg6xtio22-322320475282.asia-southeast1.run.app';
  const preUrl = 'https://ais-pre-w7nmsuf6m34trgg6xtio22-322320475282.asia-southeast1.run.app';

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  if (!isOpen) return null;

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstallable(false);
      }
      setDeferredPrompt(null);
    } else {
      // Direct instructions for mobile & desktop
      alert(
        'To install Rahosantochat on this device:\n\n' +
        '• Android (Chrome): Tap the top-right menu (⋮) -> tap "Install app" or "Add to Home screen".\n' +
        '• iPhone / iPad (Safari): Tap the Share button (square with arrow ↑) -> tap "Add to Home Screen".\n' +
        '• PC / Mac (Chrome/Edge): Click the Install icon in your browser address bar.'
      );
    }
  };

  const handleCopyLink = (url: string, type: 'dev' | 'pre') => {
    navigator.clipboard.writeText(url);
    if (type === 'dev') {
      setCopiedDevLink(true);
      setTimeout(() => setCopiedDevLink(false), 2500);
    } else {
      setCopiedPreLink(true);
      setTimeout(() => setCopiedPreLink(false), 2500);
    }
  };

  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    setDownloadSuccess(false);
    try {
      await downloadProjectZip();
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150 select-none">
      <div className="w-full max-w-lg bg-white dark:bg-[#111b21] border border-[#e9edef] dark:border-[#222d34] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-[#111b21] dark:text-[#e9edef] transition-colors">
        {/* Header */}
        <div className="p-4 border-b border-[#e9edef] dark:border-[#222d34] flex items-center justify-between bg-[#f0f2f5] dark:bg-[#202c33]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 p-0.5 shadow-sm">
              <div className="w-full h-full bg-white dark:bg-[#111b21] rounded-[10px] flex items-center justify-center">
                <Smartphone className="w-4.5 h-4.5 text-[#00a884]" />
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">Install &amp; Share Rahosantochat</h3>
              <p className="text-xs text-[#667781] dark:text-[#8696a0]">Add to Home Screen, Share Link, or Download</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] hover:bg-black/5 dark:hover:bg-white/5 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-5 pt-4">
          <div className="flex items-center gap-1 p-1 bg-[#f0f2f5] dark:bg-[#202c33] rounded-xl border border-[#e9edef] dark:border-[#222d34] text-xs">
            <button
              onClick={() => setActiveTab('mobile')}
              className={`flex-1 py-1.5 rounded-lg font-medium transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'mobile'
                  ? 'bg-white dark:bg-[#111b21] text-[#00a884] font-bold shadow-xs'
                  : 'text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>Mobile Link &amp; App</span>
            </button>
            <button
              onClick={() => setActiveTab('desktop')}
              className={`flex-1 py-1.5 rounded-lg font-medium transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'desktop'
                  ? 'bg-white dark:bg-[#111b21] text-[#00a884] font-bold shadow-xs'
                  : 'text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span>PC / Desktop</span>
            </button>
            <button
              onClick={() => setActiveTab('source')}
              className={`flex-1 py-1.5 rounded-lg font-medium transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'source'
                  ? 'bg-white dark:bg-[#111b21] text-[#00a884] font-bold shadow-xs'
                  : 'text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]'
              }`}
            >
              <HardDrive className="w-4 h-4" />
              <span>Source ZIP</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {activeTab === 'mobile' ? (
            <div className="space-y-4">
              {/* Why link wasn't working alert banner */}
              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-700/50 rounded-xl space-y-2 text-xs">
                <div className="flex items-center gap-1.5 font-semibold text-amber-800 dark:text-amber-300">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400" />
                  <span>Why Did the Link Show an Error?</span>
                </div>
                <p className="text-[11px] text-amber-900 dark:text-amber-200/90 leading-relaxed">
                  Google AI Studio protects development links with Google sign-in. To open the link on your phone:
                </p>
                <div className="text-[11px] space-y-1 text-amber-950 dark:text-amber-100/80 bg-white/60 dark:bg-black/20 p-2 rounded-lg">
                  <div>1. <strong>Sign in to Google</strong> on your phone browser with <strong>rahotma20@gmail.com</strong>, OR</div>
                  <div>2. <strong>Click &quot;Share&quot;</strong> in the top-right corner of Google AI Studio to make the link public for everyone!</div>
                </div>
              </div>

              {/* Direct Link 1: Development Link */}
              <div className="p-3.5 bg-[#f0f2f5] dark:bg-[#202c33] rounded-xl border border-[#e9edef] dark:border-[#222d34] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#111b21] dark:text-[#e9edef] flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-[#00a884]" />
                    <span>Your App Link (Current Session)</span>
                  </span>
                  <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950/60 text-[#00a884] px-1.5 py-0.5 rounded font-medium">
                    Active Now
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    readOnly
                    value={devUrl}
                    className="bg-white dark:bg-[#111b21] border border-[#e9edef] dark:border-[#222d34] text-[11px] text-[#111b21] dark:text-[#e9edef] rounded-lg px-2.5 py-1.5 flex-1 font-mono select-all"
                  />
                  <button
                    onClick={() => handleCopyLink(devUrl, 'dev')}
                    className="px-3 py-1.5 bg-[#00a884] hover:bg-[#008f72] text-white rounded-lg text-xs font-medium transition-colors shrink-0 flex items-center gap-1 shadow-xs"
                    title="Copy Link"
                  >
                    {copiedDevLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedDevLink ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-[10px] text-[#667781] dark:text-[#8696a0]">
                  Requires you to be signed in to Google with rahotma20@gmail.com on that browser.
                </p>
              </div>

              {/* Direct Link 2: Public Shared Link */}
              <div className="p-3.5 bg-[#f0f2f5] dark:bg-[#202c33] rounded-xl border border-[#e9edef] dark:border-[#222d34] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#111b21] dark:text-[#e9edef] flex items-center gap-1.5">
                    <Share className="w-3.5 h-3.5 text-blue-500" />
                    <span>Public Shared Link (For Anyone)</span>
                  </span>
                  <span className="text-[10px] bg-blue-100 dark:bg-blue-950/60 text-blue-500 px-1.5 py-0.5 rounded font-medium">
                    Requires Share in AI Studio
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    readOnly
                    value={preUrl}
                    className="bg-white dark:bg-[#111b21] border border-[#e9edef] dark:border-[#222d34] text-[11px] text-[#111b21] dark:text-[#e9edef] rounded-lg px-2.5 py-1.5 flex-1 font-mono select-all"
                  />
                  <button
                    onClick={() => handleCopyLink(preUrl, 'pre')}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium transition-colors shrink-0 flex items-center gap-1 shadow-xs"
                    title="Copy Public Link"
                  >
                    {copiedPreLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedPreLink ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-[10px] text-[#667781] dark:text-[#8696a0]">
                  Click the <strong>&quot;Share&quot;</strong> button in AI Studio top header to activate this link for public access.
                </p>
              </div>

              {/* Install Now Button if on mobile device currently */}
              {isInstallable && (
                <button
                  onClick={handleInstallPWA}
                  className="w-full py-3 bg-[#00a884] hover:bg-[#008f72] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Tap to Install on this Device</span>
                </button>
              )}

              {/* Mobile Platform Instructions */}
              <div className="space-y-3 pt-1">
                {/* Android Steps */}
                <div className="p-3.5 bg-white dark:bg-[#111b21] rounded-xl border border-[#e9edef] dark:border-[#222d34] space-y-2 text-xs shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#111b21] dark:text-[#e9edef] flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-[#00a884]" />
                      <span>Android (Chrome)</span>
                    </span>
                    <span className="text-[10px] text-[#00a884] bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/20">
                      Step-by-Step
                    </span>
                  </div>

                  <ol className="space-y-2 text-[#54656f] dark:text-[#8696a0] text-[11px] pl-1">
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-[#00a884] font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">1</span>
                      <span>Open the link in <strong>Chrome</strong> on your phone (signed in with your Google account).</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-[#00a884] font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">2</span>
                      <span>Tap the <strong>three dots menu (⋮)</strong> in the top-right corner.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-[#00a884] font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">3</span>
                      <span>Select <strong>&quot;Install app&quot;</strong> or <strong>&quot;Add to Home screen&quot;</strong>.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-[#00a884] font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">4</span>
                      <span>Tap <strong>Install</strong>. Rahosantochat will launch full-screen like a native app!</span>
                    </li>
                  </ol>
                </div>

                {/* iOS Safari Steps */}
                <div className="p-3.5 bg-white dark:bg-[#111b21] rounded-xl border border-[#e9edef] dark:border-[#222d34] space-y-2 text-xs shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#111b21] dark:text-[#e9edef] flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-blue-500" />
                      <span>iPhone &amp; iPad (Apple Safari)</span>
                    </span>
                    <span className="text-[10px] text-blue-500 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded border border-blue-500/20">
                      Step-by-Step
                    </span>
                  </div>

                  <ol className="space-y-2 text-[#54656f] dark:text-[#8696a0] text-[11px] pl-1">
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-blue-500 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">1</span>
                      <span>Open the link in <strong>Safari</strong> on your iPhone.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-blue-500 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">2</span>
                      <span>Tap the <strong>Share</strong> button <Share className="w-3.5 h-3.5 inline text-blue-500 mx-0.5" /> (square with upward arrow).</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-blue-500 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">3</span>
                      <span>Tap <strong>&quot;Add to Home Screen&quot;</strong> <PlusSquare className="w-3.5 h-3.5 inline text-blue-500 mx-0.5" />.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#f0f2f5] dark:bg-[#202c33] text-blue-500 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">4</span>
                      <span>Tap <strong>Add</strong>. The Rahosantochat app will appear on your iPhone screen!</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          ) : activeTab === 'desktop' ? (
            <div className="space-y-4">
              <div className="p-4 bg-white dark:bg-[#111b21] border border-[#e9edef] dark:border-[#222d34] rounded-2xl space-y-3 shadow-xs">
                <div className="flex items-center gap-2 font-bold text-sm text-[#111b21] dark:text-[#e9edef]">
                  <Monitor className="w-4.5 h-4.5 text-[#00a884]" />
                  <span>Desktop App Installation (Windows &amp; Mac)</span>
                </div>
                <p className="text-xs text-[#54656f] dark:text-[#8696a0] leading-relaxed">
                  You can install Rahosantochat as a standalone desktop application in Chrome, Edge, or Brave:
                </p>
                <div className="p-3 bg-[#f0f2f5] dark:bg-[#202c33] rounded-xl font-mono text-xs text-[#111b21] dark:text-[#e9edef] space-y-1.5 border border-[#e9edef] dark:border-[#222d34]">
                  <div>1. Look at the right side of your browser URL bar.</div>
                  <div>2. Click the <strong>Install</strong> icon (computer with down arrow).</div>
                  <div>3. Click <strong>Install</strong> to open in dedicated window.</div>
                </div>
                {isInstallable && (
                  <button
                    onClick={handleInstallPWA}
                    className="w-full py-2.5 bg-[#00a884] hover:bg-[#008f72] text-white font-bold text-xs rounded-xl transition-colors shadow-xs"
                  >
                    Install on this PC
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-white dark:bg-[#111b21] border border-[#e9edef] dark:border-[#222d34] rounded-2xl space-y-3 shadow-xs">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-sm text-[#111b21] dark:text-[#e9edef]">Full Application Source Code</h4>
                    <p className="text-xs text-[#54656f] dark:text-[#8696a0] mt-1">
                      Download the complete repository to host or run anywhere with 0 restrictions.
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-[#00a884] bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded">
                    ZIP Archive
                  </span>
                </div>

                <button
                  onClick={handleDownloadZip}
                  disabled={isDownloadingZip}
                  className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-xs ${
                    downloadSuccess
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#00a884] hover:bg-[#008f72] text-white'
                  }`}
                >
                  {isDownloadingZip ? (
                    <>
                      <span className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                      <span>Packaging Source Files...</span>
                    </>
                  ) : downloadSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Downloaded: Rahosantochat_Application_Source.zip</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>Download Full Application (.ZIP)</span>
                    </>
                  )}
                </button>
              </div>

              <div className="p-3 bg-[#f0f2f5] dark:bg-[#202c33] rounded-xl border border-[#e9edef] dark:border-[#222d34] space-y-2 text-xs">
                <div className="flex items-center gap-2 font-semibold text-[#111b21] dark:text-[#e9edef]">
                  <Terminal className="w-4 h-4 text-[#00a884]" />
                  <span>How to Run Locally</span>
                </div>
                <div className="bg-white dark:bg-[#111b21] p-2.5 rounded-lg font-mono text-[11px] text-[#111b21] dark:text-[#e9edef] space-y-1 border border-[#e9edef] dark:border-[#222d34]">
                  <div>1. Unzip Rahosantochat_Application_Source.zip</div>
                  <div>2. npm install</div>
                  <div>3. npm run dev</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
