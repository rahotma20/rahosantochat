import React, { useState } from 'react';
import { X, Lock, Copy, Check, Terminal, ShieldCheck, Key } from 'lucide-react';
import { Message } from '../types/chat';
import { formatTime } from '../utils/crypto';

interface CipherInspectorModalProps {
  message: Message | null;
  isOpen: boolean;
  onClose: () => void;
}

export const CipherInspectorModal: React.FC<CipherInspectorModalProps> = ({
  message,
  isOpen,
  onClose
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !message) return null;

  const payload = message.encryptedPayload;

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-slate-100">
                End-to-End Cryptographic Payload
              </h3>
              <p className="text-xs text-slate-400">
                AES-256-GCM authenticated cipher stream
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Payload Inspection Body */}
        <div className="p-5 overflow-y-auto space-y-4 font-mono text-xs">
          {/* Status Bar */}
          <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-xl flex items-center justify-between text-emerald-300">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-sans font-medium text-xs">Tamper-Proof Authenticated</span>
            </div>
            <span className="text-[11px] bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">
              Valid GCM Tag
            </span>
          </div>

          {/* Cipher Details Grid */}
          <div className="space-y-3 font-sans">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Decrypted Plaintext
              </span>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-slate-200 text-sm whitespace-pre-wrap font-sans">
                {message.text || (message.media ? `[Attached ${message.media.length} media file(s)]` : '')}
              </div>
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Ciphertext (Base64 Encrypted Stream)
              </span>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400 break-all select-all">
                {payload.ciphertext}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                  Initialization Vector (IV)
                </span>
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs text-cyan-300 break-all select-all">
                  {payload.iv}
                </div>
              </div>

              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                  Algorithm
                </span>
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs text-slate-200">
                  {payload.algorithm}
                </div>
              </div>
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Sender Session Fingerprint
              </span>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs text-amber-300 break-all">
                {payload.fingerprint}
              </div>
            </div>
          </div>

          {/* Raw JSON Copy */}
          <div className="pt-2 flex justify-between items-center border-t border-slate-800">
            <span className="text-slate-500 font-sans text-xs">
              Recorded {formatTime(payload.encryptedAt || message.timestamp)}
            </span>
            <button
              onClick={handleCopyJson}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-sans transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'JSON Copied' : 'Copy Full Payload JSON'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
