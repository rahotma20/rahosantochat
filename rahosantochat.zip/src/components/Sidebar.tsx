import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Pin, 
  Check, 
  CheckCheck, 
  Image as ImageIcon, 
  Mic, 
  FileText, 
  UserPlus, 
  Lock, 
  ChevronDown, 
  VolumeX, 
  Download, 
  RefreshCw, 
  Trash2, 
  UserX, 
  MoreVertical, 
  CircleDashed, 
  MessageSquare, 
  MessageSquarePlus, 
  Users, 
  Radio, 
  Settings, 
  Filter, 
  Sparkles,
  Sun,
  Moon
} from 'lucide-react';
import { Contact, Message, StatusStory } from '../types/chat';
import { formatTime } from '../utils/crypto';

interface SidebarProps {
  contacts: Contact[];
  activeContactId: string;
  onSelectContact: (id: string) => void;
  messages: Record<string, Message[]>;
  stories: StatusStory[];
  onOpenStoryViewer: (index: number) => void;
  onOpenNewContact: () => void;
  onOpenDownloadApp: () => void;
  onOpenSyncContacts: () => void;
  onOpenSettings: () => void;
  onDeleteContact: (contactId: string) => void;
  onClearChat: (contactId: string) => void;
  currentUser: {
    id: string;
    name: string;
    handle: string;
    avatar: string;
    status: string;
  };
  onSwitchUser: (userId: string) => void;
  theme?: 'light' | 'dark';
  onToggleTheme?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  contacts,
  activeContactId,
  onSelectContact,
  messages,
  stories,
  onOpenStoryViewer,
  onOpenNewContact,
  onOpenDownloadApp,
  onOpenSyncContacts,
  onOpenSettings,
  onDeleteContact,
  onClearChat,
  currentUser,
  onSwitchUser,
  theme = 'light',
  onToggleTheme
}) => {
  const [navTab, setNavTab] = useState<'chats' | 'status' | 'channels' | 'communities'>('chats');
  const [activeMenuContactId, setActiveMenuContactId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'unread' | 'pinned' | 'groups'>('all');
  const [showTopMenu, setShowTopMenu] = useState(false);
  const [showPersonaMenu, setShowPersonaMenu] = useState(false);

  // Channels state
  const [followedChannels, setFollowedChannels] = useState<Record<string, boolean>>({
    'rahosanto-official': true
  });

  const channelsList = [
    {
      id: 'rahosanto-official',
      name: 'Rahosantochat Official',
      avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=150&q=80',
      followers: '124K followers',
      snippet: 'Welcome to the WhatsApp UI update! Default white background and fast WebCrypto AES-256-GCM encryption enabled.'
    },
    {
      id: 'crypto-defense',
      name: 'End-to-End Cryptography Guild',
      avatar: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=150&q=80',
      followers: '89K followers',
      snippet: 'WebCrypto AES-256-GCM zero-trust protocols verified across all desktop and mobile targets.'
    },
    {
      id: 'security-bulletin',
      name: 'Tech & Privacy Insights',
      avatar: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=150&q=80',
      followers: '45K followers',
      snippet: 'Local storage transcript backup and direct vCard contacts sync now live in your browser.'
    }
  ];

  // Filter contacts by search query & filter tabs
  const filteredContacts = contacts.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.handle && c.handle.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (filterTab === 'unread') {
      const msgs = messages[c.id] || [];
      const hasUnread = msgs.some((m) => m.senderId !== 'me' && m.status !== 'read');
      return hasUnread;
    }
    if (filterTab === 'pinned') {
      return !!c.isPinned;
    }
    return true;
  });

  // Sort contacts: pinned first, then by last message timestamp
  const sortedContacts = [...filteredContacts].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;

    const msgsA = messages[a.id] || [];
    const msgsB = messages[b.id] || [];
    const timeA = msgsA.length > 0 ? msgsA[msgsA.length - 1].timestamp : 0;
    const timeB = msgsB.length > 0 ? msgsB[msgsB.length - 1].timestamp : 0;
    return timeB - timeA;
  });

  const unreadStoriesCount = stories.filter((s) => !s.isViewed).length;

  return (
    <div className="flex h-full w-full md:w-[480px] lg:w-[500px] shrink-0 bg-white dark:bg-[#111b21] border-r border-[#e9edef] dark:border-[#222d34] text-[#111b21] dark:text-[#e9edef] select-none transition-colors">
      {/* 1. Left Vertical App Rail (WhatsApp Web Style) */}
      <div className="hidden md:flex w-[60px] h-full bg-[#f0f2f5] dark:bg-[#202c33] border-r border-[#e9edef] dark:border-[#222d34] flex-col justify-between items-center py-3 shrink-0">
        {/* Top App Icons */}
        <div className="flex flex-col items-center gap-1.5 w-full">
          {/* Chats Icon */}
          <button
            onClick={() => setNavTab('chats')}
            title="Chats"
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors relative ${
              navTab === 'chats'
                ? 'bg-[#e9edef] dark:bg-[#374248] text-[#00a884]'
                : 'text-[#54656f] dark:text-[#aebac1] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef]'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="sr-only">Chats</span>
          </button>

          {/* Status / Updates Icon */}
          <button
            onClick={() => setNavTab('status')}
            title="Status"
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors relative ${
              navTab === 'status'
                ? 'bg-[#e9edef] dark:bg-[#374248] text-[#00a884]'
                : 'text-[#54656f] dark:text-[#aebac1] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef]'
            }`}
          >
            <CircleDashed className="w-5 h-5" />
            {unreadStoriesCount > 0 && (
              <span className="absolute top-2 right-2 w-2 h-2 bg-[#00a884] rounded-full ring-2 ring-[#f0f2f5] dark:ring-[#202c33]" />
            )}
            <span className="sr-only">Status</span>
          </button>

          {/* Channels Icon */}
          <button
            onClick={() => setNavTab('channels')}
            title="Channels"
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              navTab === 'channels'
                ? 'bg-[#e9edef] dark:bg-[#374248] text-[#00a884]'
                : 'text-[#54656f] dark:text-[#aebac1] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef]'
            }`}
          >
            <Radio className="w-5 h-5" />
            <span className="sr-only">Channels</span>
          </button>

          {/* Communities Icon */}
          <button
            onClick={() => setNavTab('communities')}
            title="Communities"
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              navTab === 'communities'
                ? 'bg-[#e9edef] dark:bg-[#374248] text-[#00a884]'
                : 'text-[#54656f] dark:text-[#aebac1] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef]'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="sr-only">Communities</span>
          </button>
        </div>

        {/* Bottom Rail Icons */}
        <div className="flex flex-col items-center gap-1.5 w-full">
          {/* Theme Quick Toggle Button */}
          {onToggleTheme && (
            <button
              onClick={onToggleTheme}
              title={theme === 'dark' ? 'Switch to Light (White Background)' : 'Switch to Dark Mode'}
              className="w-10 h-10 rounded-full flex items-center justify-center text-[#54656f] dark:text-[#aebac1] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef] transition-colors"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-[#54656f]" />}
            </button>
          )}

          {/* Download App / PWA shortcut */}
          <button
            onClick={onOpenDownloadApp}
            title="Install App & Download"
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#54656f] dark:text-[#aebac1] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#00a884] transition-colors"
          >
            <Download className="w-5 h-5" />
          </button>

          {/* Settings Icon */}
          <button
            onClick={onOpenSettings}
            title="Settings"
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#54656f] dark:text-[#aebac1] hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 hover:text-[#111b21] dark:hover:text-[#e9edef] transition-colors"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* User Profile Avatar with Online Ring */}
          <button
            onClick={() => setShowPersonaMenu(!showPersonaMenu)}
            title={`Logged in as ${currentUser.name} (Click to switch persona)`}
            className="w-10 h-10 rounded-full mt-1 relative group focus:outline-none"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-full h-full rounded-full object-cover ring-1 ring-gray-300 dark:ring-slate-600 group-hover:ring-[#00a884] transition-all"
            />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#25d366] rounded-full ring-2 ring-[#f0f2f5] dark:ring-[#202c33]" />
          </button>
        </div>
      </div>

      {/* 2. Main Sidebar Content Pane */}
      <aside className="flex-1 flex flex-col h-full bg-white dark:bg-[#111b21] min-w-0">
        {/* Switch Persona Popup Bar */}
        {showPersonaMenu && (
          <div className="p-3 bg-[#f0f2f5] dark:bg-[#182229] border-b border-[#e9edef] dark:border-[#222d34] text-xs shrink-0 animate-in fade-in duration-100">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-[#667781] dark:text-[#8696a0] uppercase tracking-wider text-[11px]">
                Switch Active Persona
              </span>
              <button
                onClick={() => setShowPersonaMenu(false)}
                className="text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]"
              >
                ✕
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onSwitchUser('me');
                  setShowPersonaMenu(false);
                }}
                className={`p-2 rounded-lg flex items-center gap-2 border transition-all text-left ${
                  currentUser.id === 'me'
                    ? 'bg-[#d9fdd3] dark:bg-[#005c4b]/30 border-[#00a884] text-[#008069] dark:text-[#00a884]'
                    : 'bg-white dark:bg-[#202c33] border-[#e9edef] dark:border-transparent text-[#111b21] dark:text-[#d1d7db] hover:border-[#00a884]'
                }`}
              >
                <img
                  src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"
                  alt="Rahotma"
                  className="w-6 h-6 rounded-full object-cover"
                />
                <span className="truncate font-medium">Rahotma (You)</span>
              </button>

              <button
                onClick={() => {
                  onSwitchUser('santo-rahman');
                  setShowPersonaMenu(false);
                }}
                className={`p-2 rounded-lg flex items-center gap-2 border transition-all text-left ${
                  currentUser.id === 'santo-rahman'
                    ? 'bg-[#d9fdd3] dark:bg-[#005c4b]/30 border-[#00a884] text-[#008069] dark:text-[#00a884]'
                    : 'bg-white dark:bg-[#202c33] border-[#e9edef] dark:border-transparent text-[#111b21] dark:text-[#d1d7db] hover:border-[#00a884]'
                }`}
              >
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                  alt="Santo"
                  className="w-6 h-6 rounded-full object-cover"
                />
                <span className="truncate font-medium">Santo Rahman</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 1: CHATS VIEW */}
        {navTab === 'chats' && (
          <>
            {/* WhatsApp Chats Header */}
            <div className="h-[60px] px-4 bg-[#f0f2f5] dark:bg-[#202c33] flex items-center justify-between shrink-0 border-b border-[#e9edef] dark:border-[#222d34]">
              <div className="flex items-center gap-2.5">
                <h2 className="text-xl font-bold tracking-tight text-[#111b21] dark:text-[#e9edef] flex items-center gap-1.5">
                  <span>Chats</span>
                  <span className="text-[10px] text-[#00a884] bg-[#00a884]/15 px-1.5 py-0.5 rounded font-mono font-medium">
                    WA
                  </span>
                </h2>
              </div>

              {/* WhatsApp Header Icons */}
              <div className="flex items-center gap-1 text-[#54656f] dark:text-[#aebac1]">
                <button
                  onClick={onOpenSyncContacts}
                  title="Sync Phone Contacts"
                  className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 text-[#54656f] dark:text-[#aebac1] hover:text-[#00a884] rounded-full transition-colors"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>

                <button
                  onClick={onOpenNewContact}
                  title="New chat"
                  className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 text-[#54656f] dark:text-[#aebac1] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors"
                >
                  <MessageSquarePlus className="w-5 h-5" />
                </button>

                {/* 3-Dots Top Menu */}
                <div className="relative">
                  <button
                    onClick={() => setShowTopMenu(!showTopMenu)}
                    title="Menu"
                    className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 text-[#54656f] dark:text-[#aebac1] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors"
                  >
                    <MoreVertical className="w-5 h-5" />
                  </button>

                  {showTopMenu && (
                    <div className="absolute right-0 top-full mt-2 w-56 bg-white dark:bg-[#233138] border border-[#e9edef] dark:border-[#222d34] rounded-xl shadow-2xl py-2 z-50 text-sm text-[#111b21] dark:text-[#d1d7db] animate-in fade-in zoom-in-95 duration-100">
                      <button
                        onClick={() => {
                          setShowTopMenu(false);
                          onOpenNewContact();
                        }}
                        className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
                      >
                        <UserPlus className="w-4 h-4 text-[#00a884]" />
                        <span>New contact</span>
                      </button>
                      <button
                        onClick={() => {
                          setShowTopMenu(false);
                          onOpenSyncContacts();
                        }}
                        className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
                      >
                        <RefreshCw className="w-4 h-4 text-[#00a884]" />
                        <span>Sync phone contacts</span>
                      </button>
                      <button
                        onClick={() => {
                          setShowTopMenu(false);
                          onOpenDownloadApp();
                        }}
                        className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
                      >
                        <Download className="w-4 h-4 text-[#00a884]" />
                        <span>Download app (.zip / PWA)</span>
                      </button>

                      {onToggleTheme && (
                        <button
                          onClick={() => {
                            setShowTopMenu(false);
                            onToggleTheme();
                          }}
                          className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
                        >
                          {theme === 'dark' ? (
                            <>
                              <Sun className="w-4 h-4 text-amber-500" />
                              <span>Switch to Light Theme (White)</span>
                            </>
                          ) : (
                            <>
                              <Moon className="w-4 h-4 text-[#54656f]" />
                              <span>Switch to Dark Theme</span>
                            </>
                          )}
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setShowTopMenu(false);
                          onOpenSettings();
                        }}
                        className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
                      >
                        <Settings className="w-4 h-4 text-[#667781] dark:text-[#8696a0]" />
                        <span>Settings</span>
                      </button>
                      <div className="my-1 border-t border-[#e9edef] dark:border-[#2a3942]" />
                      <button
                        onClick={() => {
                          setShowTopMenu(false);
                          setShowPersonaMenu(true);
                        }}
                        className="w-full px-4 py-2.5 text-left hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors flex items-center gap-3"
                      >
                        <Sparkles className="w-4 h-4 text-emerald-500" />
                        <span>Switch test persona</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* WhatsApp Search Bar */}
            <div className="px-3 pt-2.5 pb-2 bg-white dark:bg-[#111b21] flex items-center gap-2">
              <div className="flex-1 relative flex items-center bg-[#f0f2f5] dark:bg-[#202c33] rounded-lg px-3 py-1.5 text-sm border border-transparent focus-within:border-[#00a884] transition-colors">
                <Search className="w-4 h-4 text-[#667781] dark:text-[#8696a0] mr-3 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search or start new chat"
                  className="w-full bg-transparent text-[#111b21] dark:text-[#e9edef] placeholder-[#667781] dark:placeholder-[#8696a0] text-sm focus:outline-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] text-xs font-semibold"
                  >
                    ✕
                  </button>
                )}
              </div>
              <button
                onClick={() => setFilterTab(filterTab === 'unread' ? 'all' : 'unread')}
                title="Filter unread chats"
                className={`p-2 rounded-lg transition-colors ${
                  filterTab === 'unread'
                    ? 'bg-[#00a884] text-white'
                    : 'text-[#667781] dark:text-[#8696a0] hover:bg-[#f0f2f5] dark:hover:bg-[#202c33] hover:text-[#111b21] dark:hover:text-[#e9edef]'
                }`}
              >
                <Filter className="w-4 h-4" />
              </button>
            </div>

            {/* WhatsApp Filter Segmented Buttons */}
            <div className="px-3 py-1.5 bg-white dark:bg-[#111b21] flex items-center gap-1.5 overflow-x-auto border-b border-[#e9edef] dark:border-[#222d34]">
              {[
                { id: 'all', label: 'All' },
                { id: 'unread', label: 'Unread' },
                { id: 'pinned', label: 'Favourites' },
                { id: 'groups', label: 'Groups' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setFilterTab(tab.id as any)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors shrink-0 ${
                    filterTab === tab.id
                      ? 'bg-[#d9fdd3] dark:bg-[#0a332c] text-[#008069] dark:text-[#00a884] font-semibold'
                      : 'bg-[#f0f2f5] dark:bg-[#202c33] text-[#54656f] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#d1d7db]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* WhatsApp Chat List */}
            <div className="flex-1 overflow-y-auto divide-y divide-[#e9edef]/80 dark:divide-[#222d34]/60">
              {sortedContacts.length === 0 ? (
                <div className="p-8 text-center text-[#667781] dark:text-[#8696a0]">
                  <Search className="w-8 h-8 mx-auto mb-2 opacity-30 text-[#667781] dark:text-[#8696a0]" />
                  <p className="text-sm font-medium">No chats found</p>
                  <p className="text-xs text-[#667781] dark:text-[#8696a0] mt-1">Try searching a different name or number</p>
                </div>
              ) : (
                sortedContacts.map((contact) => {
                  const isActive = contact.id === activeContactId;
                  const contactMsgs = messages[contact.id] || [];
                  const lastMsg = contactMsgs.length > 0 ? contactMsgs[contactMsgs.length - 1] : null;
                  const unreadCount = contactMsgs.filter(
                    (m) => m.senderId !== 'me' && m.status !== 'read'
                  ).length;
                  const hasStory = stories.some((s) => s.contactId === contact.id);

                  return (
                    <div
                      key={contact.id}
                      onClick={() => onSelectContact(contact.id)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          onSelectContact(contact.id);
                        }
                      }}
                      className={`w-full px-3 py-3 flex items-center gap-3 transition-colors relative group cursor-pointer focus:outline-none ${
                        isActive
                          ? 'bg-[#f0f2f5] dark:bg-[#2a3942]'
                          : 'bg-white dark:bg-transparent hover:bg-[#f5f6f6] dark:hover:bg-[#202c33]'
                      }`}
                    >
                      {/* Circular WhatsApp Avatar with Story Ring */}
                      <div className="relative shrink-0">
                        <div
                          onClick={(e) => {
                            if (hasStory) {
                              e.stopPropagation();
                              const idx = stories.findIndex((s) => s.contactId === contact.id);
                              if (idx !== -1) onOpenStoryViewer(idx);
                            }
                          }}
                          className={`rounded-full p-0.5 transition-transform ${
                            hasStory ? 'ring-2 ring-[#00a884] cursor-pointer hover:scale-105' : ''
                          }`}
                          title={hasStory ? 'Click to view status' : ''}
                        >
                          <img
                            src={contact.avatar}
                            alt={contact.name}
                            className="w-12 h-12 rounded-full object-cover ring-1 ring-[#e9edef] dark:ring-[#222d34]"
                          />
                        </div>
                        {contact.status === 'online' && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-[#25d366] rounded-full ring-2 ring-white dark:ring-[#111b21]" />
                        )}
                      </div>

                      {/* Chat info & last message snippet */}
                      <div className="flex-1 min-w-0 pr-1">
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="font-medium text-[16px] text-[#111b21] dark:text-[#e9edef] truncate">
                            {contact.name}
                          </span>
                          {lastMsg && (
                            <span
                              className={`text-[12px] whitespace-nowrap shrink-0 ${
                                unreadCount > 0 ? 'text-[#25d366] font-semibold' : 'text-[#667781] dark:text-[#8696a0]'
                              }`}
                            >
                              {formatTime(lastMsg.timestamp)}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center justify-between gap-2 text-[13px]">
                          <div className="truncate text-[#667781] dark:text-[#8696a0] flex items-center gap-1">
                            {lastMsg ? (
                              <>
                                {/* WhatsApp Checkmark Indicators */}
                                {lastMsg.senderId === 'me' && (
                                  lastMsg.status === 'read' ? (
                                    <CheckCheck className="w-4 h-4 shrink-0 text-[#53bdeb]" />
                                  ) : lastMsg.status === 'delivered' ? (
                                    <CheckCheck className="w-4 h-4 shrink-0 text-[#667781] dark:text-[#8696a0]" />
                                  ) : (
                                    <Check className="w-4 h-4 shrink-0 text-[#667781] dark:text-[#8696a0]" />
                                  )
                                )}

                                {/* Media Attachment Snippet */}
                                {lastMsg.media && lastMsg.media.length > 0 ? (
                                  <span className="inline-flex items-center gap-1 text-[#667781] dark:text-[#8696a0]">
                                    {lastMsg.media[0].type === 'image' && <ImageIcon className="w-4 h-4 text-[#667781] dark:text-[#8696a0]" />}
                                    {lastMsg.media[0].type === 'audio' && <Mic className="w-4 h-4 text-[#00a884]" />}
                                    {lastMsg.media[0].type === 'document' && <FileText className="w-4 h-4 text-[#667781] dark:text-[#8696a0]" />}
                                    <span className="truncate">
                                      {lastMsg.media[0].type === 'audio' ? 'Voice message' : lastMsg.media[0].name}
                                    </span>
                                  </span>
                                ) : (
                                  <span className="truncate">{lastMsg.text}</span>
                                )}
                              </>
                            ) : (
                              <span className="italic text-[#667781]/70 dark:text-[#8696a0]/80">Tap to start chatting</span>
                            )}
                          </div>

                          {/* Unread badge & WhatsApp chevron menu */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            {contact.isPinned && (
                              <Pin className="w-3.5 h-3.5 text-[#667781] dark:text-[#8696a0] rotate-45" />
                            )}
                            {contact.isMuted && (
                              <VolumeX className="w-3.5 h-3.5 text-[#667781] dark:text-[#8696a0]" />
                            )}

                            {unreadCount > 0 && (
                              <span className="min-w-5 h-5 px-1.5 rounded-full bg-[#25d366] text-white font-bold text-[11px] flex items-center justify-center">
                                {unreadCount}
                              </span>
                            )}

                            {/* Dropdown Options for Clear / Delete */}
                            <div className="relative" onClick={(e) => e.stopPropagation()}>
                              <button
                                type="button"
                                onClick={() =>
                                  setActiveMenuContactId(
                                    activeMenuContactId === contact.id ? null : contact.id
                                  )
                                }
                                className="p-1 text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                title="Chat options"
                              >
                                <ChevronDown className="w-4 h-4" />
                              </button>

                              {activeMenuContactId === contact.id && (
                                <div className="absolute right-0 top-full mt-1 w-52 bg-white dark:bg-[#233138] border border-[#e9edef] dark:border-[#222d34] rounded-xl shadow-2xl py-1.5 z-40 text-xs text-[#111b21] dark:text-[#d1d7db] animate-in fade-in zoom-in-95 duration-100">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onClearChat(contact.id);
                                      setActiveMenuContactId(null);
                                    }}
                                    className="w-full px-4 py-2 text-left flex items-center gap-2.5 text-amber-600 dark:text-amber-400 hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                    <span>Clear chat messages</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      onDeleteContact(contact.id);
                                      setActiveMenuContactId(null);
                                    }}
                                    className="w-full px-4 py-2 text-left flex items-center gap-2.5 text-rose-600 dark:text-rose-400 hover:bg-[#f5f6f6] dark:hover:bg-[#182229] transition-colors font-medium"
                                  >
                                    <UserX className="w-4 h-4" />
                                    <span>Delete person &amp; chat</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </>
        )}

        {/* TAB 2: STATUS / UPDATES VIEW */}
        {navTab === 'status' && (
          <div className="flex-1 flex flex-col h-full bg-white dark:bg-[#111b21] overflow-y-auto">
            <div className="h-[60px] px-4 bg-[#f0f2f5] dark:bg-[#202c33] flex items-center justify-between shrink-0 border-b border-[#e9edef] dark:border-[#222d34]">
              <h2 className="text-xl font-bold tracking-tight text-[#111b21] dark:text-[#e9edef]">Status</h2>
              <button
                onClick={() => onOpenStoryViewer(0)}
                className="p-2 hover:bg-[#e9edef] dark:hover:bg-[#374248]/50 text-[#00a884] rounded-full transition-colors"
                title="View stories"
              >
                <CircleDashed className="w-5 h-5" />
              </button>
            </div>

            {/* My Status */}
            <div className="p-3 bg-white dark:bg-[#111b21] border-b border-[#e9edef] dark:border-[#222d34]">
              <div 
                onClick={() => onOpenStoryViewer(0)}
                className="flex items-center gap-3 p-2 rounded-xl hover:bg-[#f5f6f6] dark:hover:bg-[#202c33] cursor-pointer transition-colors"
              >
                <div className="relative">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-[#00a884] text-white flex items-center justify-center font-bold text-xs ring-2 ring-white dark:ring-[#111b21]">
                    +
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef]">My status</h4>
                  <p className="text-xs text-[#667781] dark:text-[#8696a0]">Click to view or add new update</p>
                </div>
              </div>
            </div>

            {/* Recent Updates List */}
            <div className="p-3">
              <span className="text-xs font-semibold text-[#667781] dark:text-[#8696a0] uppercase tracking-wider px-2">
                Recent Updates
              </span>

              <div className="mt-2 space-y-1">
                {stories.map((story, idx) => (
                  <div
                    key={story.id}
                    onClick={() => onOpenStoryViewer(idx)}
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#f5f6f6] dark:hover:bg-[#202c33] cursor-pointer transition-colors"
                  >
                    <div className="w-12 h-12 rounded-full p-0.5 ring-2 ring-[#00a884] overflow-hidden shrink-0">
                      <img
                        src={story.contactAvatar}
                        alt={story.contactName}
                        className="w-full h-full object-cover rounded-full"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h5 className="font-medium text-sm text-[#111b21] dark:text-[#e9edef] truncate">{story.contactName}</h5>
                      <p className="text-xs text-[#667781] dark:text-[#8696a0]">
                        {new Date(story.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CHANNELS VIEW */}
        {navTab === 'channels' && (
          <div className="flex-1 flex flex-col h-full bg-white dark:bg-[#111b21] overflow-y-auto">
            <div className="h-[60px] px-4 bg-[#f0f2f5] dark:bg-[#202c33] flex items-center justify-between shrink-0 border-b border-[#e9edef] dark:border-[#222d34]">
              <h2 className="text-xl font-bold tracking-tight text-[#111b21] dark:text-[#e9edef]">Channels</h2>
              <span className="text-xs text-[#00a884] font-medium">Broadcasts</span>
            </div>

            <div className="p-4 space-y-4">
              <p className="text-xs text-[#667781] dark:text-[#8696a0] leading-relaxed">
                Stay updated on security releases, E2EE protocol audits, and feature announcements.
              </p>

              <div className="space-y-3">
                {channelsList.map((ch) => {
                  const isFollowed = followedChannels[ch.id];
                  return (
                    <div
                      key={ch.id}
                      className="p-3 rounded-xl bg-[#f0f2f5] dark:bg-[#202c33] border border-[#e9edef] dark:border-[#222d34] flex items-start gap-3"
                    >
                      <img
                        src={ch.avatar}
                        alt={ch.name}
                        className="w-11 h-11 rounded-full object-cover shrink-0 ring-1 ring-[#00a884]"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <h4 className="font-semibold text-sm text-[#111b21] dark:text-[#e9edef] truncate">{ch.name}</h4>
                          <button
                            onClick={() =>
                              setFollowedChannels((prev) => ({ ...prev, [ch.id]: !isFollowed }))
                            }
                            className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors ${
                              isFollowed
                                ? 'bg-transparent text-[#00a884] border border-[#00a884]'
                                : 'bg-[#00a884] text-white hover:bg-[#02906f]'
                            }`}
                          >
                            {isFollowed ? 'Following' : 'Follow'}
                          </button>
                        </div>
                        <p className="text-[11px] text-[#00a884] mt-0.5">{ch.followers}</p>
                        <p className="text-xs text-[#667781] dark:text-[#8696a0] mt-1.5 leading-relaxed line-clamp-2">
                          {ch.snippet}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: COMMUNITIES VIEW */}
        {navTab === 'communities' && (
          <div className="flex-1 flex flex-col h-full bg-white dark:bg-[#111b21] overflow-y-auto">
            <div className="h-[60px] px-4 bg-[#f0f2f5] dark:bg-[#202c33] flex items-center justify-between shrink-0 border-b border-[#e9edef] dark:border-[#222d34]">
              <h2 className="text-xl font-bold tracking-tight text-[#111b21] dark:text-[#e9edef]">Communities</h2>
            </div>
            <div className="p-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#00a884]/20 text-[#00a884] flex items-center justify-center mx-auto">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg text-[#111b21] dark:text-[#e9edef]">Stay connected with your community</h3>
              <p className="text-xs text-[#667781] dark:text-[#8696a0] max-w-xs mx-auto leading-relaxed">
                Communities bring members together in topic-based groups and make it easy to manage multiple chat channels.
              </p>
              <button
                onClick={onOpenNewContact}
                className="px-5 py-2.5 rounded-full bg-[#00a884] hover:bg-[#02906f] text-white font-semibold text-xs transition-transform active:scale-95 shadow-md"
              >
                Start your community
              </button>
            </div>
          </div>
        )}

        {/* Bottom Encryption Footnote */}
        <div className="p-2.5 bg-white dark:bg-[#111b21] border-t border-[#e9edef] dark:border-[#222d34] text-[11px] text-[#667781] dark:text-[#8696a0] flex items-center justify-center gap-1.5 text-center shrink-0">
          <Lock className="w-3 h-3 text-[#667781] dark:text-[#8696a0]" />
          <span>Your personal messages are end-to-end encrypted</span>
        </div>

        {/* Mobile Bottom Navigation Bar (Visible only on mobile screens < 768px) */}
        <div className="md:hidden h-14 bg-[#f0f2f5] dark:bg-[#202c33] border-t border-[#e9edef] dark:border-[#222d34] flex items-center justify-around shrink-0 text-xs">
          <button
            onClick={() => setNavTab('chats')}
            className={`flex flex-col items-center justify-center gap-1 ${
              navTab === 'chats' ? 'text-[#00a884]' : 'text-[#667781] dark:text-[#8696a0]'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[10px]">Chats</span>
          </button>

          <button
            onClick={() => setNavTab('status')}
            className={`flex flex-col items-center justify-center gap-1 relative ${
              navTab === 'status' ? 'text-[#00a884]' : 'text-[#667781] dark:text-[#8696a0]'
            }`}
          >
            <CircleDashed className="w-5 h-5" />
            {unreadStoriesCount > 0 && (
              <span className="absolute top-0 right-3 w-2 h-2 bg-[#00a884] rounded-full" />
            )}
            <span className="text-[10px]">Updates</span>
          </button>

          <button
            onClick={() => setNavTab('communities')}
            className={`flex flex-col items-center justify-center gap-1 ${
              navTab === 'communities' ? 'text-[#00a884]' : 'text-[#667781] dark:text-[#8696a0]'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px]">Communities</span>
          </button>

          <button
            onClick={onOpenSettings}
            className="flex flex-col items-center justify-center gap-1 text-[#667781] dark:text-[#8696a0]"
          >
            <Settings className="w-5 h-5" />
            <span className="text-[10px]">Settings</span>
          </button>
        </div>
      </aside>
    </div>
  );
};
