import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  Phone, 
  Mail, 
  Bell, 
  BellOff, 
  Pin, 
  Trash2, 
  Download, 
  Image as ImageIcon, 
  FileText, 
  Mic, 
  Timer,
  ChevronRight,
  UserX,
  Star
} from 'lucide-react';
import { Contact, Message, MediaAttachment } from '../types/chat';
import { formatBytes } from '../utils/crypto';

interface ContactDrawerProps {
  contact: Contact;
  isOpen: boolean;
  onClose: () => void;
  messages: Message[];
  onOpenSafetyVerification: () => void;
  onOpenLightbox: (media: MediaAttachment) => void;
  onUpdateContact: (updated: Partial<Contact>) => void;
  onClearChat: () => void;
  onDeleteContact: () => void;
  onExportChat: () => void;
}

export const ContactDrawer: React.FC<ContactDrawerProps> = ({
  contact,
  isOpen,
  onClose,
  messages,
  onOpenSafetyVerification,
  onOpenLightbox,
  onUpdateContact,
  onClearChat,
  onDeleteContact,
  onExportChat
}) => {
  const [activeMediaTab, setActiveMediaTab] = useState<'photos' | 'docs' | 'audio'>('photos');

  if (!isOpen) return null;

  const allMedia: MediaAttachment[] = [];
  messages.forEach((m) => {
    if (m.media) {
      allMedia.push(...m.media);
    }
  });

  const photoMedia = allMedia.filter((m) => m.type === 'image' || m.type === 'video');
  const docMedia = allMedia.filter((m) => m.type === 'document');
  const audioMedia = allMedia.filter((m) => m.type === 'audio');

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full sm:w-[420px] bg-white dark:bg-[#111b21] border-l border-[#e9edef] dark:border-[#222d34] shadow-2xl flex flex-col animate-in slide-in-from-right duration-200 text-[#111b21] dark:text-[#e9edef] select-none transition-colors">
      {/* WhatsApp Contact Info Header Bar */}
      <div className="h-[60px] px-4 bg-[#f0f2f5] dark:bg-[#202c33] border-b border-[#e9edef] dark:border-[#222d34] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-1 text-[#54656f] dark:text-[#aebac1] hover:text-[#111b21] dark:hover:text-[#e9edef] rounded-full transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <h3 className="font-medium text-[16px] text-[#111b21] dark:text-[#e9edef]">Contact info</h3>
        </div>
      </div>

      {/* WhatsApp Drawer Scrollable Content */}
      <div className="flex-1 overflow-y-auto space-y-2 bg-[#f0f2f5] dark:bg-[#0c1317]">
        {/* Profile Avatar & Name Card */}
        <div className="bg-white dark:bg-[#111b21] p-6 text-center shadow-xs border-b border-[#e9edef] dark:border-[#222d34]">
          <div className="relative inline-block mb-4">
            <img
              src={contact.avatar}
              alt={contact.name}
              className="w-44 h-44 rounded-full object-cover ring-2 ring-[#e9edef] dark:ring-[#222d34] shadow-md mx-auto"
            />
          </div>
          <h2 className="text-xl font-medium text-[#111b21] dark:text-[#e9edef]">{contact.name}</h2>
          <p className="text-sm text-[#667781] dark:text-[#8696a0] mt-1">{contact.phone}</p>
        </div>

        {/* About / Status Section */}
        <div className="bg-white dark:bg-[#111b21] p-4 border-y border-[#e9edef] dark:border-[#222d34] space-y-1">
          <span className="text-[12px] font-normal text-[#667781] dark:text-[#8696a0]">About</span>
          <p className="text-sm text-[#111b21] dark:text-[#e9edef]">{contact.role || 'Hey there! I am using Rahosanto.'}</p>
        </div>

        {/* Media, Links and Docs Section */}
        <div className="bg-white dark:bg-[#111b21] p-4 border-y border-[#e9edef] dark:border-[#222d34] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-[#111b21] dark:text-[#e9edef]">
              Media, links and docs
            </span>
            <span className="text-xs text-[#667781] dark:text-[#8696a0] flex items-center gap-1">
              <span>{allMedia.length}</span>
              <ChevronRight className="w-4 h-4" />
            </span>
          </div>

          {/* Media Sub-tabs */}
          <div className="flex items-center gap-1 p-1 bg-[#f0f2f5] dark:bg-[#202c33] rounded-lg text-xs">
            <button
              onClick={() => setActiveMediaTab('photos')}
              className={`flex-1 py-1 rounded-md text-center transition-colors ${
                activeMediaTab === 'photos'
                  ? 'bg-white dark:bg-[#111b21] text-[#00a884] font-semibold shadow-xs'
                  : 'text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]'
              }`}
            >
              Media ({photoMedia.length})
            </button>
            <button
              onClick={() => setActiveMediaTab('docs')}
              className={`flex-1 py-1 rounded-md text-center transition-colors ${
                activeMediaTab === 'docs'
                  ? 'bg-white dark:bg-[#111b21] text-[#00a884] font-semibold shadow-xs'
                  : 'text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]'
              }`}
            >
              Docs ({docMedia.length})
            </button>
            <button
              onClick={() => setActiveMediaTab('audio')}
              className={`flex-1 py-1 rounded-md text-center transition-colors ${
                activeMediaTab === 'audio'
                  ? 'bg-white dark:bg-[#111b21] text-[#00a884] font-semibold shadow-xs'
                  : 'text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]'
              }`}
            >
              Audio ({audioMedia.length})
            </button>
          </div>

          {/* Media Gallery Thumbnails */}
          {activeMediaTab === 'photos' && (
            photoMedia.length === 0 ? (
              <p className="text-xs text-[#667781] dark:text-[#8696a0] py-3 text-center">No media shared</p>
            ) : (
              <div className="grid grid-cols-3 gap-1.5">
                {photoMedia.map((m) => (
                  <div
                    key={m.id}
                    onClick={() => onOpenLightbox(m)}
                    className="aspect-square rounded-lg overflow-hidden bg-gray-100 dark:bg-[#202c33] cursor-pointer hover:opacity-90 transition-opacity"
                  >
                    <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )
          )}

          {activeMediaTab === 'docs' && (
            docMedia.length === 0 ? (
              <p className="text-xs text-[#667781] dark:text-[#8696a0] py-3 text-center">No documents shared</p>
            ) : (
              <div className="space-y-1.5">
                {docMedia.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-2.5 bg-[#f0f2f5] dark:bg-[#202c33] rounded-lg flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-4 h-4 text-[#00a884] shrink-0" />
                      <span className="truncate text-[#111b21] dark:text-[#e9edef]">{doc.name}</span>
                    </div>
                    <a
                      href={doc.url}
                      download={doc.name}
                      className="p-1 text-[#667781] dark:text-[#8696a0] hover:text-[#00a884]"
                    >
                      <Download className="w-4 h-4" />
                    </a>
                  </div>
                ))}
              </div>
            )
          )}

          {activeMediaTab === 'audio' && (
            audioMedia.length === 0 ? (
              <p className="text-xs text-[#667781] dark:text-[#8696a0] py-3 text-center">No voice notes shared</p>
            ) : (
              <div className="space-y-1.5">
                {audioMedia.map((aud) => (
                  <div
                    key={aud.id}
                    className="p-2.5 bg-[#f0f2f5] dark:bg-[#202c33] rounded-lg flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <Mic className="w-4 h-4 text-[#00a884]" />
                      <span className="text-[#111b21] dark:text-[#e9edef]">{aud.name}</span>
                    </div>
                    <span className="text-[#667781] dark:text-[#8696a0] text-[11px]">{aud.duration || 30}s</span>
                  </div>
                ))}
              </div>
            )
          )}
        </div>

        {/* WhatsApp Chat Settings & Controls */}
        <div className="bg-white dark:bg-[#111b21] divide-y divide-[#e9edef] dark:divide-[#222d34] border-y border-[#e9edef] dark:border-[#222d34] text-sm">
          {/* Mute Notifications */}
          <button
            onClick={() => onUpdateContact({ isMuted: !contact.isMuted })}
            className="w-full p-4 flex items-center justify-between hover:bg-[#f5f6f6] dark:hover:bg-[#202c33] transition-colors"
          >
            <div className="flex items-center gap-4">
              {contact.isMuted ? (
                <BellOff className="w-5 h-5 text-[#667781] dark:text-[#8696a0]" />
              ) : (
                <Bell className="w-5 h-5 text-[#667781] dark:text-[#8696a0]" />
              )}
              <span>Mute notifications</span>
            </div>
            <span className="text-xs text-[#667781] dark:text-[#8696a0]">
              {contact.isMuted ? 'Muted' : 'Off'}
            </span>
          </button>

          {/* Disappearing Messages */}
          <div className="p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Timer className="w-5 h-5 text-[#667781] dark:text-[#8696a0]" />
                <span>Disappearing messages</span>
              </div>
              <span className="text-xs text-[#00a884] font-medium">
                {contact.disappearingTimer === 0
                  ? 'Off'
                  : `${contact.disappearingTimer / 3600} hours`}
              </span>
            </div>
            <div className="flex gap-1 pt-1">
              {[
                { label: 'Off', val: 0 },
                { label: '24 Hours', val: 86400 },
                { label: '7 Days', val: 604800 },
                { label: '90 Days', val: 7776000 }
              ].map((option) => (
                <button
                  key={option.label}
                  onClick={() => onUpdateContact({ disappearingTimer: option.val })}
                  className={`flex-1 py-1 text-xs rounded-md transition-colors ${
                    contact.disappearingTimer === option.val
                      ? 'bg-[#00a884] text-white font-semibold'
                      : 'bg-[#f0f2f5] dark:bg-[#202c33] text-[#667781] dark:text-[#8696a0] hover:text-[#111b21] dark:hover:text-[#e9edef]'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* Encryption / Safety Number Verification */}
          <button
            onClick={onOpenSafetyVerification}
            className="w-full p-4 flex items-center justify-between hover:bg-[#f5f6f6] dark:hover:bg-[#202c33] transition-colors text-left"
          >
            <div className="flex items-center gap-4">
              <Lock className="w-5 h-5 text-[#667781] dark:text-[#8696a0] shrink-0" />
              <div>
                <p className="text-sm text-[#111b21] dark:text-[#e9edef]">Encryption</p>
                <p className="text-xs text-[#667781] dark:text-[#8696a0]">
                  Messages and calls are end-to-end encrypted. Tap to verify.
                </p>
              </div>
            </div>
            <ShieldCheck className="w-5 h-5 text-[#00a884] shrink-0" />
          </button>

          {/* Export Transcript */}
          <button
            onClick={onExportChat}
            className="w-full p-4 flex items-center justify-between hover:bg-[#f5f6f6] dark:hover:bg-[#202c33] transition-colors text-left"
          >
            <div className="flex items-center gap-4">
              <Download className="w-5 h-5 text-[#667781] dark:text-[#8696a0]" />
              <span>Export chat</span>
            </div>
            <ChevronRight className="w-4 h-4 text-[#667781] dark:text-[#8696a0]" />
          </button>

          {/* Clear Chat */}
          <button
            onClick={onClearChat}
            className="w-full p-4 flex items-center gap-4 text-amber-600 dark:text-amber-400 hover:bg-[#f5f6f6] dark:hover:bg-[#202c33] transition-colors"
          >
            <Trash2 className="w-5 h-5" />
            <span>Clear chat</span>
          </button>

          {/* Delete Contact */}
          <button
            onClick={onDeleteContact}
            className="w-full p-4 flex items-center gap-4 text-rose-600 dark:text-rose-400 hover:bg-[#f5f6f6] dark:hover:bg-[#202c33] transition-colors font-medium"
          >
            <UserX className="w-5 h-5" />
            <span>Delete contact</span>
          </button>
        </div>
      </div>
    </div>
  );
};
