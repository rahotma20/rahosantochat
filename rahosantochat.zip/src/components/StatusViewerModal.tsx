import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, ChevronLeft, ChevronRight, Send, Heart, Smile } from 'lucide-react';
import { StatusStory } from '../types/chat';

interface StatusViewerModalProps {
  stories: StatusStory[];
  initialIndex?: number;
  isOpen: boolean;
  onClose: () => void;
  onReplyToStory: (contactId: string, replyText: string) => void;
}

export const StatusViewerModal: React.FC<StatusViewerModalProps> = ({
  stories,
  initialIndex = 0,
  isOpen,
  onClose,
  onReplyToStory
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [showReplySent, setShowReplySent] = useState(false);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(Math.min(initialIndex, stories.length - 1));
      setProgress(0);
      setIsPaused(false);
    }
  }, [isOpen, initialIndex, stories.length]);

  const currentStory = stories[currentIndex];

  useEffect(() => {
    if (!isOpen || !currentStory || isPaused) return;

    const interval = 50; // update every 50ms
    const totalDuration = 6000; // 6s per story
    const increment = (interval / totalDuration) * 100;

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((c) => c + 1);
            return 0;
          } else {
            clearInterval(timerRef.current);
            onClose();
            return 100;
          }
        }
        return prev + increment;
      });
    }, interval);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isOpen, currentIndex, currentStory, isPaused, stories.length, onClose]);

  if (!isOpen || !currentStory) return null;

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((c) => c + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((c) => c - 1);
      setProgress(0);
    }
  };

  const handleSendReply = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!replyText.trim()) return;

    onReplyToStory(
      currentStory.contactId,
      `Replying to status: "${currentStory.text || 'Photo'}" ➔ ${replyText.trim()}`
    );
    setReplyText('');
    setShowReplySent(true);
    setTimeout(() => setShowReplySent(false), 2000);
  };

  const handleQuickReaction = (emoji: string) => {
    onReplyToStory(
      currentStory.contactId,
      `Reacted with ${emoji} to status`
    );
    setShowReplySent(true);
    setTimeout(() => setShowReplySent(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0b141a]/95 backdrop-blur-md flex items-center justify-center select-none animate-in fade-in duration-200">
      {/* WhatsApp Story Card */}
      <div 
        className="relative w-full max-w-md h-[90vh] max-h-[820px] rounded-2xl overflow-hidden shadow-2xl flex flex-col justify-between border border-[#222d34]"
        style={{ backgroundColor: currentStory.backgroundColor || '#111b21' }}
        onMouseDown={() => setIsPaused(true)}
        onMouseUp={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        {/* Top Story Header & Segmented Progress Bars */}
        <div className="absolute top-0 inset-x-0 z-20 p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
          {/* WhatsApp Segmented Progress Bar */}
          <div className="flex items-center gap-1.5 mb-3">
            {stories.map((story, idx) => (
              <div
                key={story.id}
                className="flex-1 h-1 bg-white/25 rounded-full overflow-hidden"
              >
                <div
                  className="h-full bg-white transition-all duration-75 ease-linear rounded-full"
                  style={{
                    width:
                      idx < currentIndex
                        ? '100%'
                        : idx === currentIndex
                        ? `${progress}%`
                        : '0%'
                  }}
                />
              </div>
            ))}
          </div>

          {/* User info & controls */}
          <div className="flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full p-0.5 ring-2 ring-[#00a884] overflow-hidden bg-[#202c33]">
                <img
                  src={currentStory.contactAvatar}
                  alt={currentStory.contactName}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <div>
                <h4 className="font-semibold text-sm leading-tight text-white drop-shadow-sm">
                  {currentStory.contactName}
                </h4>
                <p className="text-[11px] text-white/70 leading-tight">
                  {new Date(currentStory.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsPaused(!isPaused)}
                className="p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10"
                title={isPaused ? 'Resume' : 'Pause'}
              >
                {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Story Body */}
        <div className="relative flex-1 flex items-center justify-center p-6 text-center">
          {currentStory.mediaUrl ? (
            <div className="w-full h-full flex flex-col items-center justify-center relative">
              <img
                src={currentStory.mediaUrl}
                alt="Story"
                className="max-h-[65vh] w-auto max-w-full rounded-xl object-contain shadow-lg"
              />
              {currentStory.text && (
                <div className="mt-4 px-4 py-2 bg-black/60 backdrop-blur-xs rounded-xl max-w-xs text-white text-sm font-medium">
                  {currentStory.text}
                </div>
              )}
            </div>
          ) : (
            <div className="max-w-xs">
              <p className="text-xl sm:text-2xl font-medium text-white leading-relaxed tracking-wide drop-shadow-md">
                {currentStory.text}
              </p>
            </div>
          )}

          {/* Left/Right navigation tap zones */}
          <button
            type="button"
            onClick={handlePrev}
            className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-black/30 hover:bg-black/50 text-white rounded-full backdrop-blur-xs opacity-0 hover:opacity-100 transition-opacity"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-black/30 hover:bg-black/50 text-white rounded-full backdrop-blur-xs opacity-0 hover:opacity-100 transition-opacity"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Bottom Reply Bar */}
        <div className="z-20 p-3 bg-gradient-to-t from-black/90 via-black/50 to-transparent">
          {/* Quick Reaction Emojis */}
          <div className="flex items-center justify-center gap-3 mb-2">
            {['👍', '❤️', '😂', '😮', '😢', '🙏'].map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => handleQuickReaction(emoji)}
                className="text-xl hover:scale-125 transition-transform"
                title={`React with ${emoji}`}
              >
                {emoji}
              </button>
            ))}
          </div>

          {/* Reply Form */}
          <form onSubmit={handleSendReply} className="flex items-center gap-2">
            <div className="flex-1 relative flex items-center bg-[#202c33]/90 rounded-full px-4 py-2 text-sm border border-white/20 focus-within:border-[#00a884]">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Reply to status..."
                className="w-full bg-transparent text-white placeholder-white/60 focus:outline-none text-sm"
              />
            </div>
            <button
              type="submit"
              disabled={!replyText.trim()}
              className="p-2.5 rounded-full bg-[#00a884] disabled:opacity-40 text-[#111b21] hover:bg-[#02906f] transition-all shrink-0"
              title="Send reply"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {showReplySent && (
            <p className="text-center text-[#00a884] text-xs font-medium mt-1">
              ✓ Encrypted reply sent to {currentStory.contactName}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
