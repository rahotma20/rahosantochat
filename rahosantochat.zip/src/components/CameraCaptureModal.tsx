import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, RotateCcw, Check, AlertCircle } from 'lucide-react';
import { MediaAttachment } from '../types/chat';

interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPhotoCaptured: (attachment: MediaAttachment) => void;
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onPhotoCaptured
}) => {
  const [photoDataUrl, setPhotoDataUrl] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    setPhotoDataUrl(null);
    setCameraError(null);

    navigator.mediaDevices?.getUserMedia({ video: { facingMode: 'user' }, audio: false })
      .then((stream) => {
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      })
      .catch((err) => {
        setCameraError('Unable to access webcam. Please check your camera permissions.');
      });

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setPhotoDataUrl(dataUrl);

    // Stop video stream preview
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
    }
  };

  const retakePhoto = () => {
    setPhotoDataUrl(null);
    navigator.mediaDevices?.getUserMedia({ video: { facingMode: 'user' }, audio: false })
      .then((stream) => {
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      })
      .catch(() => {
        setCameraError('Camera re-initialization failed');
      });
  };

  const handleConfirm = () => {
    if (!photoDataUrl) return;
    const attachment: MediaAttachment = {
      id: `snap-${Date.now()}`,
      type: 'image',
      url: photoDataUrl,
      name: `Camera_Snapshot_${Date.now().toString().slice(-4)}.jpg`,
      size: Math.round(photoDataUrl.length * 0.75),
      mimeType: 'image/jpeg'
    };
    onPhotoCaptured(attachment);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-emerald-400" />
            <h3 className="font-semibold text-sm text-slate-100">Live Camera Snapshot</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Camera Preview Area */}
        <div className="relative aspect-[4/3] bg-black flex items-center justify-center overflow-hidden">
          {cameraError ? (
            <div className="p-6 text-center text-rose-400 space-y-2">
              <AlertCircle className="w-8 h-8 mx-auto" />
              <p className="text-sm font-medium">{cameraError}</p>
            </div>
          ) : photoDataUrl ? (
            <img src={photoDataUrl} alt="Captured" className="w-full h-full object-cover" />
          ) : (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover mirror"
            />
          )}
        </div>

        {/* Controls */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-center gap-4">
          {!cameraError && !photoDataUrl && (
            <button
              onClick={capturePhoto}
              className="w-14 h-14 rounded-full border-4 border-white flex items-center justify-center p-1 bg-white/20 hover:bg-white/40 transition-transform active:scale-95"
              title="Take Photo"
            >
              <div className="w-full h-full bg-white rounded-full" />
            </button>
          )}

          {photoDataUrl && (
            <>
              <button
                onClick={retakePhoto}
                className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Retake</span>
              </button>
              <button
                onClick={handleConfirm}
                className="flex items-center gap-1.5 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold rounded-xl transition-colors shadow-lg"
              >
                <Check className="w-4 h-4" />
                <span>Attach to Chat</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
