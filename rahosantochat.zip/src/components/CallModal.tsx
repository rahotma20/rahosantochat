import React, { useState, useEffect, useRef } from 'react';
import { 
  PhoneOff, 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  ShieldCheck, 
  Volume2, 
  Maximize2 
} from 'lucide-react';
import { Contact } from '../types/chat';

interface CallModalProps {
  contact: Contact | null;
  callType: 'audio' | 'video';
  isOpen: boolean;
  onEndCall: () => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  contact,
  callType,
  isOpen,
  onEndCall
}) => {
  const [callStatus, setCallStatus] = useState<'connecting' | 'ringing' | 'connected'>('connecting');
  const [seconds, setSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(callType === 'audio');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isOpen || !contact) return;

    setCallStatus('connecting');
    setSeconds(0);

    const timer1 = setTimeout(() => {
      setCallStatus('ringing');
    }, 1000);

    const timer2 = setTimeout(() => {
      setCallStatus('connected');
    }, 2800);

    // If video call, try accessing webcam
    if (callType === 'video') {
      navigator.mediaDevices?.getUserMedia({ video: true, audio: true })
        .then((stream) => {
          streamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch(() => {
          // Camera not available or allowed, fallback gracefully
        });
    }

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isOpen, callType, contact]);

  // Call duration counter once connected
  useEffect(() => {
    if (callStatus !== 'connected') return;
    const interval = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [callStatus]);

  if (!isOpen || !contact) return null;

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
    if (streamRef.current) {
      streamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = isMuted;
      });
    }
  };

  const handleToggleVideo = () => {
    setIsVideoOff(!isVideoOff);
    if (streamRef.current) {
      streamRef.current.getVideoTracks().forEach((track) => {
        track.enabled = isVideoOff;
      });
    }
  };

  const formatCallTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200 select-none">
      <div className="w-full max-w-lg bg-[#111b21] border border-[#222d34] rounded-3xl overflow-hidden shadow-2xl flex flex-col relative aspect-[4/5] sm:aspect-square">
        {/* Top Encryption Header */}
        <div className="absolute top-4 inset-x-4 z-20 flex items-center justify-between pointer-events-none">
          <div className="flex items-center gap-2 px-3 py-1 bg-[#202c33]/80 backdrop-blur rounded-full border border-[#222d34] text-xs text-[#00a884]">
            <ShieldCheck className="w-4 h-4 text-[#00a884]" />
            <span>End-to-end encrypted</span>
          </div>

          <div className="px-3 py-1 bg-[#202c33]/80 backdrop-blur rounded-full border border-[#222d34] text-xs text-[#8696a0] font-mono">
            {callStatus === 'connected' ? formatCallTime(seconds) : callStatus.toUpperCase()}
          </div>
        </div>

        {/* Video feed or Audio representation */}
        <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-gradient-to-b from-slate-900 to-slate-950">
          {callType === 'video' && !isVideoOff ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover mirror"
            />
          ) : (
            <div className="text-center z-10 space-y-4">
              <div className="relative inline-block">
                <img
                  src={contact.avatar}
                  alt={contact.name}
                  className="w-28 h-28 rounded-full object-cover ring-4 ring-emerald-500/30 mx-auto shadow-2xl"
                />
                {callStatus === 'ringing' && (
                  <span className="absolute inset-0 rounded-full ring-4 ring-emerald-500/80 animate-ping" />
                )}
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{contact.name}</h3>
                <p className="text-xs text-slate-400 mt-1">{contact.role}</p>
                <p className="text-xs font-semibold text-emerald-400 mt-2">
                  {callStatus === 'connecting'
                    ? 'Connecting AES-256 stream...'
                    : callStatus === 'ringing'
                    ? 'Ringing...'
                    : 'Call Secure & Active'}
                </p>
              </div>
            </div>
          )}

          {/* Mini Contact Video Overlay when video call */}
          {callType === 'video' && (
            <div className="absolute bottom-24 right-4 w-28 h-36 rounded-2xl overflow-hidden border-2 border-emerald-500/50 shadow-2xl bg-slate-950 z-20">
              <img
                src={contact.avatar}
                alt={contact.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-1 left-2 text-[10px] text-white font-medium bg-black/60 px-1 rounded">
                {contact.name.split(' ')[0]}
              </div>
            </div>
          )}
        </div>

        {/* Controls Footer */}
        <div className="p-6 bg-[#202c33] border-t border-[#222d34] flex items-center justify-center gap-5 z-20">
          <button
            onClick={handleToggleMute}
            className={`p-4 rounded-full transition-all ${
              isMuted
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                : 'bg-[#374248] text-[#e9edef] hover:bg-[#435259]'
            }`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {callType === 'video' && (
            <button
              onClick={handleToggleVideo}
              className={`p-4 rounded-full transition-all ${
                isVideoOff
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                  : 'bg-[#374248] text-[#e9edef] hover:bg-[#435259]'
              }`}
              title={isVideoOff ? 'Enable camera' : 'Disable camera'}
            >
              {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
            </button>
          )}

          {/* WhatsApp Red Hang Up Button */}
          <button
            onClick={onEndCall}
            className="p-4 bg-[#ea0038] hover:bg-[#ff1744] text-white rounded-full transition-transform active:scale-90 shadow-lg shadow-black/50"
            title="End Call"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};
